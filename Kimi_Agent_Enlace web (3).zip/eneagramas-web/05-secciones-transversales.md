# 🌐 SECCIONES TRANSVERSALES
## Blog, Tienda, Comunidad, Eventos

---

## 📚 BLOG / RECURSOS

### Propósito
Centro de contenido etiquetado por estación, tríada y tema. Cada artículo puede pertenecer a múltiples estaciones si aborda conexiones.

### Estructura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  R E C U R S O S   Y   A P R E N D I Z A J E                                │
│                                                                             │
│  [🔍 Buscar recursos...    ]                                                │
│                                                                             │
│  FILTRAR POR:                                                               │
│  [Todas las estaciones ▼] [Tríada ▼] [Formato ▼] [Nivel ▼] [Tema ▼]        │
│                                                                             │
│  ETIQUETAS POPULARES:                                                       │
│  #autoconocimiento #relaciones #trabajo #heridas #tipo1 #tríada-mental      │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  DESTACADOS:                                                                │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ [IMAGEN GRANDE]                                                      │   │
│  │                                                                      │   │
│  │ TAGS: Estación 4, Estación 6, Integración                            │   │
│  │                                                                      │   │
│  │ "Cuando la búsqueda de identidad encuentra la seguridad:             │   │
│  │  el camino del 4 al 6"                                               │   │
│  │                                                                      │   │
│  │ [Leer artículo →]                                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [IMG]           │  │ [IMG]           │  │ [IMG]           │             │
│  │ TAG: Estación 1 │  │ TAG: Estación 7 │  │ TAG: Estación 3 │             │
│  │                 │  │                 │  │                 │             │
│  │ "La perfección  │  │ "El miedo a     │  │ "Éxito vs.      │             │
│  │  consciente"    │  │  perderse"      │  │  realización"   │             │
│  │ [Leer →]        │  │ [Leer →]        │  │ [Leer →]        │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  [Cargar más recursos ↓]                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Ficha de Artículo

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  [NAV]                                                                      │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TAGS: Estación 4 │ Estación 6 │ Integración │ Tríada Mental               │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  TÍTULO DEL ARTÍCULO                                                        │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Por [Autor] │ 📅 [Fecha] │ ⏱️ [Tiempo de lectura]                         │
│                                                                             │
│  [IMAGEN DESTACADA]                                                         │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  Contenido del artículo...                                                  │
│                                                                             │
│  Con bloques de:                                                            │
│  • Texto enriquecido                                                        │
│  • Citas destacadas                                                         │
│  • Imágenes                                                                 │
│  • Videos embebidos                                                         │
│  • Llamados a la acción                                                     │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  🌟 CONECTA CON ESTE CONTENIDO                                              │
│                                                                             │
│  Este artículo habla de las conexiones entre:                               │
│  • [Estación 4: Devida Elección]                                            │
│  • [Estación 6: El Centro de Mando]                                         │
│                                                                             │
│  Si te interesó este tema, explora:                                         │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │ [ICON 4]        │  │ [ICON 6]        │                                   │
│  │ DEVIDA          │  │ CENTRO DE       │                                   │
│  │ ELECCIÓN        │  │ MANDO           │                                   │
│  │ [Explorar →]    │  │ [Explorar →]    │                                   │
│  └─────────────────┘  └─────────────────┘                                   │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  📚 RECURSOS RELACIONADOS                                                   │
│                                                                             │
│  • [Artículo relacionado 1]                                                 │
│  • [Artículo relacionado 2]                                                 │
│  • [PDF descargable relacionado]                                            │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  💬 ¿TE RESONÓ ESTE CONTENIDO?                                              │
│                                                                             │
│  [Compartir en Facebook] [Twitter] [WhatsApp] [Copiar link]                 │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  📝 COMENTARIOS                                                             │
│                                                                             │
│  [Dejar un comentario...]                                                   │
│                                                                             │
│  [Comentarios existentes...]                                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🛒 TIENDA / CURSOS

### Propósito
Ofrecer productos digitales, cursos, sesiones y membresías. Con capacidad de paquetes por tríadas y viajes completos.

### Estructura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  T I E N D A   S A B E R   C O N S E N T I D O                              │
│                                                                             │
│  [🔍 Buscar productos...    ]                                               │
│                                                                             │
│  FILTRAR POR:                                                               │
│  [Todas las categorías ▼] [Estación ▼] [Precio ▼] [Formato ▼]              │
│                                                                             │
│  CATEGORÍAS:                                                                │
│  [Todos] [Cursos] [Sesiones] [Membresías] [Paquetes] [Gratuitos]           │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  📦 PAQUETES DESTACADOS                                                     │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   VIAJE COMPLETO: LAS 9 ESTACIONES                                  │   │
│  │                                                                     │   │
│  │   Acceso a todo el ecosistema: cursos de las 9 estaciones,          │   │
│  │   sesiones grupales mensuales, comunidad privada, recursos          │   │
│  │   exclusivos.                                                       │   │
│  │                                                                     │   │
│  │   💰 $997 (valor $1,497)                                            │   │
│  │                                                                     │   │
│  │   [Ver detalles →]                                                  │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ 📦              │  │ 📦              │  │ 📦              │             │
│  │ COLECCIÓN       │  │ COLECCIÓN       │  │ COLECCIÓN       │             │
│  │ TRÍADA MENTAL   │  │ TRÍADA          │  │ TRÍADA          │             │
│  │ (5-6-7)         │  │ EMOCIONAL       │  │ INSTINTIVA      │             │
│  │                 │  │ (2-3-4)         │  │ (8-9-1)         │             │
│  │ $297            │  │ $297            │  │ $297            │             │
│  │ [Ver →]         │  │ [Ver →]         │  │ [Ver →]         │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  🎯 CURSOS POR ESTACIÓN                                                     │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [IMG]           │  │ [IMG]           │  │ [IMG]           │             │
│  │ CURSO           │  │ CURSO           │  │ CURSO           │             │
│  │                 │  │                 │  │                 │             │
│  │ "El Ritmo       │  │ "Lazos del      │  │ "Roles y        │             │
│  │  Justo"         │  │  Alma"          │  │  Sinergia"      │             │
│  │                 │  │                 │  │                 │             │
│  │ ⭐⭐⭐⭐⭐ (24)    │  │ ⭐⭐⭐⭐⭐ (18)    │  │ ⭐⭐⭐⭐⭐ (31)    │             │
│  │ 💰 $97          │  │ 💰 $97          │  │ 💰 $97          │             │
│  │ [Ver curso →]   │  │ [Ver curso →]   │  │ [Ver curso →]   │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  [Ver todos los cursos →]                                                   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  👤 SESIONES INDIVIDUALES                                                   │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │ [FOTO]          │  │ [FOTO]          │                                   │
│  │                 │  │                 │                                   │
│  │ Sesión          │  │ Sesión          │                                   │
│  │ Descubrimiento  │  │ Acompañamiento  │                                   │
│  │ (90 min)        │  │ (4 sesiones)    │                                   │
│  │                 │  │                 │                                   │
│  │ 💰 $150         │  │ 💰 $500         │                                   │
│  │ [Reservar →]    │  │ [Reservar →]    │                                   │
│  └─────────────────┘  └─────────────────┘                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Ficha de Producto

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  [NAV]                                                                      │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Inicio > Tienda > Cursos > El Ritmo Justo                                  │
│                                                                             │
│  TAG: Estación 1 │ Tríada Instintiva │ Nivel: Introductorio                 │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  E L   R I T M O   J U S T O                                                │
│  Curso de organización consciente para el alma del Tipo 1                   │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ╭──────────────────────────╮  ╭──────────────────────────────────────────╮ │
│  │                          │  │                                          │ │
│  │   [VIDEO PREVIEW         │  │   ⭐⭐⭐⭐⭐ (24 reseñas)                   │ │
│  │    O IMAGEN]             │  │                                          │ │
│  │                          │  │   💰 $97 USD                             │ │
│  │   [▶️ Ver preview]       │  │   o 3x $33                               │ │
│  │                          │  │                                          │ │
│  ╰──────────────────────────╯  │   🎁 Incluye:                            │ │
│                                │   • 6 módulos de video                     │ │
│   📸 [IMG] [IMG] [IMG] [IMG]   │   • Workbook descargable                   │ │
│                                │   • Meditaciones guiadas                   │ │
│   [💬 Ver 24 reseñas]          │   • Acceso de por vida                     │ │
│                                │   • Certificado de finalización            │ │
│                                │                                          │ │
│                                │   [🛒 Comprar ahora]                      │ │
│                                │   [💳 Pago seguro con Stripe]             │ │
│                                │                                          │ │
│                                ╰──────────────────────────────────────────╯ │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  📋 DESCRIPCIÓN                                                             │
│                                                                             │
│  ¿Te sientes atrapado entre el deber y el deseo? ¿Tu búsqueda de            │
│  perfección te paraliza en lugar de impulsarte?                             │
│                                                                             │
│  Este curso te acompaña a transformar tu relación con la organización,      │
│  desde la rigidez hacia la fluidez consciente.                              │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  📚 CONTENIDO DEL CURSO                                                     │
│                                                                             │
│  Módulo 1: Reconociendo tu ritmo actual                                     │
│  Módulo 2: La crítica como compañera, no como juez                          │
│  Módulo 3: El deber y el deseo: reconciliando opuestos                    │
│  Módulo 4: La belleza de lo suficientemente bueno                           │
│  Módulo 5: Organización consciente vs. perfección compulsiva                │
│  Módulo 6: Integración: tu ritmo justo                                      │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  🌟 ESTE CURSO SE CONECTA CON                                               │
│                                                                             │
│  • [Estación 7: Conciencia Energética] - Tu camino de integración           │
│  • [Estación 4: Devida Elección] - Zona de alerta                           │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  💬 RESEÑAS                                                                 │
│                                                                             │
│  ⭐⭐⭐⭐⭐ "Transformador"                                                   │
│  "Por primera vez pude ver mi perfeccionismo como aliado, no enemigo."      │
│  — Ana P.                                                                   │
│                                                                             │
│  [Ver todas las reseñas →]                                                  │
│                                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│                                                                             │
│  🎁 TAMBIÉN TE PUEDE INTERESAR                                              │
│                                                                             │
│  • [Paquete Tríada Instintiva]                                              │
│  • [Sesión individual de Ritmo Justo]                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 👥 COMUNIDAD

### Propósito
Espacio de encuentro para miembros, foros de discusión por estación, grupos de apoyo.

### Estructura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  C O M U N I D A D   S A B E R   C O N S E N T I D O                        │
│                                                                             │
│  "Un espacio seguro para explorar quiénes somos y quiénes podemos ser."     │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │   👥 +500       │  │   📚 +50        │  │   🎯 +20        │             │
│  │   miembros      │  │   recursos      │  │   eventos/año   │             │
│  │   activos       │  │   exclusivos    │  │   en vivo       │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  [💬 Unirme al grupo de Facebook]    [💬 Unirme al Discord]                 │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  🏠 ESPACIOS DE LA COMUNIDAD                                                │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  💬 FORO GENERAL                                                    │   │
│  │  Comparte tu experiencia, haz preguntas, conecta con otros.         │   │
│  │                                                                     │   │
│  │  [Últimos temas:]                                                   │   │
│  │  • "¿Cómo identifico mi ala?" — 12 respuestas                       │   │
│  │  • "Mi experiencia en el camino del 4 al 1" — 8 respuestas          │   │
│  │  • "Recursos para trabajar el miedo" — 15 respuestas                │   │
│  │                                                                     │   │
│  │  [Entrar al foro →]                                                 │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [ICON 1]        │  │ [ICON 2]        │  │ [ICON 3]        │             │
│  │ RITMO           │  │ LAZOS           │  │ ROLES           │             │
│  │ JUSTO           │  │ ALMA            │  │ SINERGIA        │             │
│  │                 │  │                 │  │                 │             │
│  │ Grupo para      │  │ Grupo para      │  │ Grupo para      │             │
│  │ quienes         │  │ quienes         │  │ quienes         │             │
│  │ transitan la    │  │ transitan la    │  │ transitan la    │             │
│  │ búsqueda de la  │  │ búsqueda del    │  │ búsqueda del    │             │
│  │ perfección      │  │ vínculo         │  │ éxito           │             │
│  │ consciente      │  │ consciente      │  │ auténtico       │             │
│  │                 │  │                 │  │                 │             │
│  │ [Unirme →]      │  │ [Unirme →]      │  │ [Unirme →]      │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  [Ver todos los grupos →]                                                   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  📅 PRÓXIMOS EVENTOS PARA LA COMUNIDAD                                      │
│                                                                             │
│  • 📅 15 Mar — Taller mensual: "El Centro de Mando" (Abierto)               │
│  • 📅 22 Mar — Círculo de Tipo 4 (Solo miembros)                            │
│  • 📅 29 Mar — Integración: Viaje del 6 al 9 (Abierto)                      │
│                                                                             │
│  [Ver calendario completo →]                                                │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  💬 TESTIMONIOS DE LA COMUNIDAD                                             │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  "Encontré en esta comunidad algo que no encontré en otros         │   │
│  │   espacios de Eneagrama: profundidad sin dogmatismo,                │   │
│  │   compañía sin competencia."                                        │   │
│  │                                                                     │   │
│  │   ─── Laura G. │ Tipo 6 │ Miembro desde 2023                        │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  [Ver más testimonios →]                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📅 EVENTOS

### Propósito
Calendario de talleres, círculos, sesiones grupales y eventos especiales.

### Estructura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  E V E N T O S   S A B E R   C O N S E N T I D O                            │
│                                                                             │
│  [📅 Marzo 2024] [←] [→]                                                    │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ╭──────────────────────────────────────────────────────────────────────╮  │
│  │                                                                      │  │
│  │  📅 15 DE MARZO, 2024 │ 🕐 19:00 hs (GMT-3)                          │  │
│  │                                                                      │  │
│  │  ═════════════════════════════════════════════════════════════════  │  │
│  │  E L   C E N T R O   D E   M A N D O                                  │  │
│  │  Taller de toma de decisiones conscientes                             │  │
│  │  ═════════════════════════════════════════════════════════════════  │  │
│  │                                                                      │  │
│  │  [IMAGEN DEL EVENTO]                                                  │  │
│  │                                                                      │  │
│  │  📍 Online en vivo (Zoom)                                             │  │
│  │  ⏱️ Duración: 2 horas                                                 │  │
│  │  🎫 20 plazas disponibles                                             │  │
│  │  💰 $30 USD (o incluido en membresía)                                 │  │
│  │                                                                      │  │
│  │  [Reservar mi plaza →]                                                │  │
│  │                                                                      │  │
│  ╰──────────────────────────────────────────────────────────────────────╯  │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  📅 PRÓXIMOS EVENTOS                                                        │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ 📅 22 Mar       │  │ 📅 29 Mar       │  │ 📅 05 Abr       │             │
│  │ 🕐 19:00 hs     │  │ 🕐 19:00 hs     │  │ 🕐 19:00 hs     │             │
│  │                 │  │                 │  │                 │             │
│  │ [ICON 3]        │  │ [ICON 7]        │  │ [ICON 2]        │             │
│  │ ROLES Y         │  │ CONCIENCIA      │  │ LAZOS DEL       │             │
│  │ SINERGIA        │  │ ENERGÉTICA      │  │ ALMA            │             │
│  │                 │  │                 │  │                 │             │
│  │ $30 │ [Ver →]   │  │ $30 │ [Ver →]   │  │ $30 │ [Ver →]   │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  [Ver calendario completo →]                                                │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  🔄 EVENTOS RECURRENTES                                                     │
│                                                                             │
│  • 🗓️ Primer martes de mes: Taller de la Estación del Mes                  │
│  • 🗓️ Tercer jueves de mes: Círculo de Integración                         │
│  • 🗓️ Último sábado de mes: Sesión de preguntas y respuestas               │
│                                                                             │
│  [Suscribirme al calendario →]                                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
