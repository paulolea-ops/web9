# 📈 ESTRATEGIA DE CONVERSIÓN Y EMBUDOS

---

## 🎯 MAPA DE CONVERSIÓN

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MAPA DE EMBUDOS DEL SISTEMA                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TRÁFICO                                                                    │
│     │                                                                       │
│     ├─── ORGÁNICO (SEO, redes sociales)                                     │
│     ├─── PAGADO (Facebook, Instagram, Google)                               │
│     └─── REFERIDO (comunidad, colaboraciones)                               │
│     │                                                                       │
│     ▼                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  PÁGINA DE ENTRADA                                                  │   │
│  │  • Home (Matriz)                                                    │   │
│  │  • Estación específica (1-8)                                        │   │
│  │  • Blog/Artículo                                                    │   │
│  │  • Landing de evento                                                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│     │                                                                       │
│     ├─── Test de orientación ──→ Lead magnet ──→ Email ──→ Nurturing      │
│     │                                                                       │
│     ├─── Lead magnet directo ──→ Email ──→ Serie valor ──→ Oferta         │
│     │                                                                       │
│     └─── Contenido blog ──→ Relacionado ──→ Producto ──→ Compra           │
│     │                                                                       │
│     ▼                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  CONVERSIÓN                                                         │   │
│  │  • Lead (email capturado)                                           │   │
│  │  • Cliente (compra única)                                           │   │
│  │  • Miembro (suscripción)                                            │   │
│  │  • Embajador (referidos)                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎁 LEAD MAGNETS POR ESTACIÓN

Cada estación tiene un lead magnet específico que resuena con su dolor principal.

### Estación 1: El Ritmo Justo

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"5 señales de que tu perfeccionismo te sabotea"** | PDF | No reconocer el patrón |
| **"Checklist: La organización consciente"** | PDF/Notion | Desorganación paralizante |
| **"Meditación: Soltar el control"** | Audio | Tensión crónica |

**Embudo**:
```
Landing/Popup → Captura email → Envía PDF
                                    ↓
                    Email 1 (día 1): "¿Te resonó el checklist?"
                                    ↓
                    Email 2 (día 3): "La historia de María y el perfeccionismo"
                                    ↓
                    Email 3 (día 5): "Curso: El Ritmo Justo" (oferta)
                                    ↓
                    Email 4 (día 7): "Última oportunidad" (urgencia)
```

---

### Estación 2: Lazos del Alma

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Das demasiado? El test del agotamiento empático"** | Quiz | No reconocer límites |
| **"Guía: Cómo pedir ayuda sin sentir culpa"** | PDF | Dificultad para recibir |
| **"Ritual: La sanación del vínculo consigo mismo"** | Video | Autoabandono |

---

### Estación 3: Roles y Sinergia

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Éxito o realización? El diagnóstico"** | Quiz | Confusión de metas |
| **"Template: Mi definición de éxito auténtico"** | PDF/Worksheet | Falta de claridad |
| **"Meditación: Quién soy sin mis logros"** | Audio | Identidad ligada a logros |

---

### Estación 4: Devida Elección

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Tu dolor te define? El mapa de tu historia"** | PDF/Worksheet | Identidad en la carencia |
| **"Ejercicio: Encontrar tu voz única"** | Video | Falta de originalidad |
| **"Playlist: Música para el alma del 4"** | Spotify | Soledad emocional |

---

### Estación 5: Patrones Invisibles

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"El mapa de tu psique: Guía de autoanálisis"** | PDF | Confusión interna |
| **"Checklist: Señales de aislamiento intelectual"** | PDF | Aislamiento |
| **"Video: Cómo compartir tu conocimiento sin agotarte"** | Video | Acaparamiento de conocimiento |

---

### Estación 6: El Centro de Mando

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Duda o intuición? El test de tus decisiones"** | Quiz | Parálisis por análisis |
| **"Framework: Toma de decisiones conscientes"** | PDF | Indecisión crónica |
| **"Meditación: Encontrar tu brújula interna"** | Audio | Búsqueda de autoridad externa |

---

### Estación 7: Conciencia Energética

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Huyes del dolor? El mapa de tus escapes"** | PDF | Evitación compulsiva |
| **"Lista: 50 experiencias significativas (no necesitas más)"** | PDF | FOMO, acumulación |
| **"Ejercicio: El placer consciente"** | Video | Placer vacío |

---

### Estación 8: El Hábito de la Personalidad

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Control o protección? El test de tu poder"** | Quiz | Confusión de intenciones |
| **"Guía: La vulnerabilidad como fortaleza"** | PDF | Miedo a la debilidad |
| **"Ritual: El encuentro con tu suavidad"** | Video | Dureza crónica |

---

### Matriz (Estación 9): Saber Consentido

| Lead Magnet | Formato | Dolor que resuelve |
|-------------|---------|-------------------|
| **"¿Por dónde empiezo? Test de orientación"** | Quiz | Confusión inicial |
| **"Mapa: Las 9 estaciones del ser"** | PDF/Infografía | Visión fragmentada |
| **"Ebook: Eneagrama sin dogmas"** | PDF | Información confusa |

---

## 💰 OFERTAS COMBINADAS

### Por Tríadas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  📦 COLECCIÓN TRÍADA MENTAL (5-6-7)                                         │
│                                                                             │
│  Incluye:                                                                   │
│  • Curso: Patrones Invisibles                                               │
│  • Curso: El Centro de Mando                                                │
│  • Curso: Conciencia Energética                                             │
│  • Bonus: Sesión grupal de integración                                      │
│                                                                             │
│  Valor individual: $291                                                     │
│  Precio paquete: $197 (32% off)                                             │
│                                                                             │
│  [Comprar ahora →]                                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Paquetes disponibles**:
- Tríada Mental (5-6-7): $197
- Tríada Emocional (2-3-4): $197
- Tríada Instintiva (8-9-1): $197

### Por Viaje de Alas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🪽 VIAJE DE ALAS: 1 → 9 → 2                                                │
│                                                                             │
│  El camino del perfeccionista que encuentra la paz                          │
│  y aprende a amar sin perderse                                              │
│                                                                             │
│  Incluye:                                                                   │
│  • Ritmo Justo (1)                                                          │
│  • Saber Consentido (9)                                                     │
│  • Lazos del Alma (2)                                                       │
│  • Bonus: 3 sesiones grupales de integración                                │
│                                                                             │
│  Precio: $247 (vs $291 individual)                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Viaje Completo

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  🌟 VIAJE COMPLETO: LAS 9 ESTACIONES                                        │
│                                                                             │
│  El ecosistema completo de autoconocimiento                                 │
│                                                                             │
│  Incluye:                                                                   │
│  ✓ Los 9 cursos completos ($873 valor)                                      │
│  ✓ Sesiones grupales mensuales ($600 valor)                                 │
│  ✓ Comunidad privada ($200 valor)                                           │
│  ✓ Recursos exclusivos ($100 valor)                                         │
│  ✓ 2 sesiones individuales ($300 valor)                                     │
│                                                                             │
│  Valor total: $2,073                                                        │
│  Precio especial: $997 (52% off)                                            │
│                                                                             │
│  [Quiero el viaje completo →]                                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 👥 ESTRATEGIA DE COMUNIDAD

### Grupos por Estación

| Grupo | Plataforma | Contenido |
|-------|------------|-----------|
| **Ritmo Justo** | Facebook/Discord | Organización, perfeccionismo, ética |
| **Lazos del Alma** | Facebook/Discord | Vínculos, límites, dar y recibir |
| **Roles y Sinergia** | Facebook/Discord | Éxito, imagen, autenticidad |
| **Devida Elección** | Facebook/Discord | Identidad, creatividad, profundidad |
| **Patrones Invisibles** | Facebook/Discord | Análisis, conocimiento, observación |
| **Centro de Mando** | Facebook/Discord | Decisiones, seguridad, autoridad |
| **Conciencia Energética** | Facebook/Discord | Placer, entusiasmo, moderación |
| **El Hábito** | Facebook/Discord | Poder, vulnerabilidad, impacto |
| **General** | Facebook/Discord | Integración, todas las estaciones |

### Embudo de Comunidad

```
Visitante → Contenido gratuito → Lead magnet → Email
                                              ↓
                                    Invitación a grupo público
                                              ↓
                                    Participación activa
                                              ↓
                                    Oferta membresía privada
                                              ↓
                                    Miembro → Embajador
```

---

## 🎤 EVENTOS EN VIVO ROTATIVOS

### Calendario de Eventos

| Mes | Estación Anfitriona | Evento |
|-----|---------------------|--------|
| Enero | 1 - Ritmo Justo | "Nuevo año, nuevo ritmo" |
| Febrero | 2 - Lazos del Alma | "Sanando el amor" |
| Marzo | 3 - Roles y Sinergia | "Éxito consciente" |
| Abril | 4 - Devida Elección | "Encontrando tu voz" |
| Mayo | 5 - Patrones Invisibles | "El mapa de tu mente" |
| Junio | 6 - Centro de Mando | "Decisiones sin miedo" |
| Julio | 7 - Conciencia Energética | "El placer consciente" |
| Agosto | 8 - El Hábito | "Poder sin violencia" |
| Septiembre | 9 - Saber Consentido | "Integración total" |
| Octubre | Integración | "Viaje de alas" |
| Noviembre | Integración | "Viaje de flechas" |
| Diciembre | Integración | "Cierre y celebración" |

### Estructura de Evento

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  TALLER MENSUAL: [Nombre de la Estación]                                    │
│                                                                             │
│  📅 Fecha: Primer sábado de mes                                             │
│  🕐 Duración: 3 horas                                                       │
│  📍 Modalidad: Online en vivo (Zoom)                                        │
│  💰 Precio: $30 (o incluido en membresía)                                   │
│                                                                             │
│  Estructura:                                                                │
│  • 30 min: Bienvenida y presentación                                        │
│  • 60 min: Contenido principal de la estación                               │
│  • 30 min: Ejercicio práctico grupal                                        │
│  • 30 min: Preguntas y respuestas                                           │
│  • 30 min: Conexiones: alas y flechas                                       │
│                                                                             │
│  Bonus: Grabación disponible por 30 días                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## ⭐ PRUEBA SOCIAL SEGMENTADA

### Testimonios por Estación

Cada página de estación muestra testimonios específicos:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  💬 TESTIMONIOS DE EL RITMO JUSTO                                           │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  "Por primera vez pude ver mi perfeccionismo como aliado,           │   │
│  │   no enemigo. El curso me dio herramientas para organizarme         │   │
│  │   sin torturarme."                                                  │   │
│  │                                                                     │   │
│  │   ⭐⭐⭐⭐⭐                                                          │   │
│  │   ─── Ana P. │ Tipo 1 │ Coach                                       │   │
│  │                                                                     │   │
│  │   [🎥 Ver video]                                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  "El concepto de 'ritmo justo' cambió mi relación con el trabajo.   │   │
│  │   Ahora produzco más y sufro menos."                                │   │
│  │                                                                     │   │
│  │   ⭐⭐⭐⭐⭐                                                          │   │
│  │   ─── Carlos M. │ Tipo 1 │ Emprendedor                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  [Ver más testimonios →]                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Casos de Uso

| Tipo | Contenido | Ubicación |
|------|-----------|-----------|
| **Testimonio video** | 2-3 minutos | Página de estación, Home |
| **Testimonio escrito** | 2-3 párrafos | Página de estación, Producto |
| **Caso de estudio** | 1-2 páginas | Blog, Lead magnet |
| **Antes/Después** | Visual | Home, Landing pages |

---

## 📊 MÉTRICAS CLAVE (KPIs)

### Métricas de Tráfico

| Métrica | Objetivo Mensual | Herramienta |
|---------|------------------|-------------|
| Visitantes únicos | 10,000 | Google Analytics |
| Páginas por sesión | 3+ | Google Analytics |
| Tiempo en sitio | 3+ minutos | Google Analytics |
| Tasa de rebote | <50% | Google Analytics |

### Métricas de Conversión

| Métrica | Objetivo | Herramienta |
|---------|----------|-------------|
| Tasa de conversión a lead | 5% | FluentCRM |
| Tasa de conversión a cliente | 10% de leads | WooCommerce |
| Tasa de conversión a miembro | 5% de clientes | MemberPress |
| Valor de vida del cliente (LTV) | $300+ | WooCommerce |

### Métricas de Engagement

| Métrica | Objetivo | Herramienta |
|---------|----------|-------------|
| Tasa de apertura de emails | 25%+ | FluentCRM |
| Tasa de click en emails | 3%+ | FluentCRM |
| Miembros activos en comunidad | 30%+ | Facebook/Discord |
| Asistencia a eventos | 40% de inscritos | Amelia |

---

## 🗓️ CALENDARIO DE LANZAMIENTO

### Fase 1: Pre-lanzamiento (Mes 1)

| Semana | Actividad |
|--------|-----------|
| 1 | Configurar sitio, diseñar Home |
| 2 | Crear 3 estaciones principales (1, 5, 9) |
| 3 | Configurar tienda y pagos |
| 4 | Crear lead magnets y embudos básicos |

### Fase 2: Lanzamiento Suave (Mes 2)

| Semana | Actividad |
|--------|-----------|
| 1 | Abrir a lista de espera (beta) |
| 2 | Recopilar feedback, ajustar |
| 3 | Crear 3 estaciones más (2, 4, 6) |
| 4 | Lanzar primer evento en vivo |

### Fase 3: Lanzamiento Público (Mes 3)

| Semana | Actividad |
|--------|-----------|
| 1 | Completar 9 estaciones |
| 2 | Lanzar campaña de ads |
| 3 | Activar programa de afiliados |
| 4 | Evento de lanzamiento oficial |

### Fase 4: Escalamiento (Mes 4+)

| Mes | Actividad |
|-----|-----------|
| 4 | Optimizar embudos según datos |
| 5 | Lanzar membresía premium |
| 6 | Crear cursos avanzados |
| 7+ | Escalar tráfico y ofertas |

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
