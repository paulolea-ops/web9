# 🎨 IDENTIDAD VISUAL POR ESTACIÓN
## Sistema Cromático y de Diseño

---

## 🎯 PRINCIPIOS DE IDENTIDAD VISUAL

> "Cada estación tiene su propia voz, pero todas cantan en el mismo coro. La coherencia visual no significa uniformidad: significa familia."

### Directrices Generales

1. **Unidad en la diversidad**: Cada estación es única pero reconocible como parte del sistema
2. **El color habla**: Cada estación tiene una paleta emocional definida
3. **La tipografía transmite**: Fuentes que reflejan el carácter de cada eneatipo
4. **Los iconos simbolizan**: Representaciones visuales de la esencia

---

## 🌈 PALETA CROMÁTICA COMPLETA

### Resumen Visual de Colores

```
┌────────────────────────────────────────────────────────────────────────┐
│                    PALETA DE LAS 9 ESTACIONES                          │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ESTACIÓN 1: EL RITMO JUSTO           ESTACIÓN 2: LAZOS DEL ALMA       │
│  ████████ Azul Sereno #4A6FA5         ████████ Terracota #C67B5C       │
│  ████████ Gris Perla #B8B8B8          ████████ Rosa Antiguo #D4A5A5     │
│  ████████ Blanco Hielo #F5F7FA        ████████ Crema Cálida #F5E6DC     │
│                                                                        │
│  ESTACIÓN 3: ROLES Y SINERGIA         ESTACIÓN 4: DEVIDA ELECCIÓN      │
│  ████████ Verde Esmeralda #2D8A6E     ████████ Violeta #6B4C7F         │
│  ████████ Dorado Suave #D4AF37        ████████ Burdeos #722F37         │
│  ████████ Verde Menta #A8E6CF         ████████ Lavanda #E6E6FA         │
│                                                                        │
│  ESTACIÓN 5: PATRONES INVISIBLES      ESTACIÓN 6: EL CENTRO DE MANDO   │
│  ████████ Azul Profundo #1E3A5F       ████████ Gris Carbón #36454F     │
│  ████████ Cobre #B87333               ████████ Ámbar #FFBF00           │
│  ████████ Azul Eléctrico #00BFFF      ████████ Gris Plata #C0C0C0      │
│                                                                        │
│  ESTACIÓN 7: CONCIENCIA ENERGÉTICA    ESTACIÓN 8: EL HÁBITO            │
│  ████████ Magenta #FF00FF             ████████ Negro #0D0D0D           │
│  ████████ Cian Eléctrico #00FFFF      ████████ Oro Quemado #8B6914     │
│  ████████ Amarillo Solar #FFD700      ████████ Rojo Oscuro #4A0404     │
│                                                                        │
│  ESTACIÓN 9: SABER CONSENTIDO (Matriz)                                 │
│  ████████ Sepia #704214               ████████ Dorado Antiguo #C5B358  │
│  ████████ Beige Sabio #F5F5DC         ████████ Marrón Tierra #8B4513   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 DETALLE POR ESTACIÓN

### 🔵 ESTACIÓN 1: EL RITMO JUSTO

**Eneatipo**: 1 (El Perfeccionista/Etico)  
**Esencia**: "La acción ética que se vuelve fluidez"  
**Emoción**: Ira → Serenidad

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Azul Sereno | `#4A6FA5` | Headers, botones principales, acentos |
| **Secundario** | Gris Perla | `#B8B8B8` | Fondos, separadores, texto secundario |
| **Terciario** | Blanco Hielo | `#F5F7FA` | Fondos de sección, tarjetas |
| **Acento** | Azul Noche | `#2E4A6F` | Hover, énfasis |
| **Texto** | Gris Oscuro | `#333333` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Playfair Display* o *Cinzel* — Elegancia clásica, autoridad
- **Cuerpo**: *Source Sans Pro* o *Open Sans* — Legibilidad, claridad
- **Énfasis**: *IBM Plex Mono* — Precisión, estructura

#### Iconografía

- **Icono principal**: Metrónomo o Balanza
- **Símbolos secundarios**: Brújula, Regla, Checklist
- **Estilo**: Líneas limpias, geométrico, preciso

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Precisión, calma, orden     │
│                                         │
│  • Líneas rectas y limpias              │
│  • Espacios generosos (white space)     │
│  • Grid estructurado                    │
│  • Fotografía: minimalista, ordenada    │
│  • Animaciones: suaves, medidas         │
│                                         │
└─────────────────────────────────────────┘
```

---

### 🟠 ESTACIÓN 2: LAZOS DEL ALMA

**Eneatipo**: 2 (El Ayudador)  
**Esencia**: "El arte consciente del vínculo"  
**Emoción**: Orgullo → Humildad auténtica

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Terracota | `#C67B5C` | Headers, botones, acentos |
| **Secundario** | Rosa Antiguo | `#D4A5A5` | Fondos suaves, highlights |
| **Terciario** | Crema Cálida | `#F5E6DC` | Fondos de sección |
| **Acento** | Coral Profundo | `#B85C3F` | Hover, CTA |
| **Texto** | Marrón Suave | `#5C4033` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Cormorant Garamond* o *Lora* — Calidez, elegancia
- **Cuerpo**: *Nunito* o *Quicksand* — Amigable, acogedora
- **Énfasis**: *Dancing Script* — Toque personal, manuscrito

#### Iconografía

- **Icono principal**: Corazón entrelazado o Manos unidas
- **Símbolos secundarios**: Abrazo, Flores, Red conexiones
- **Estilo**: Orgánico, curvilíneo, suave

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Calidez, cercanía, amor     │
│                                         │
│  • Formas orgánicas y curvas            │
│  • Texturas suaves (papel, tela)        │
│  • Espacios acogedores                  │
│  • Fotografía: retratos, conexión       │
│  • Animaciones: fluidas, acariciantes   │
│                                         │
└─────────────────────────────────────────┘
```

---

### 🟢 ESTACIÓN 3: ROLES Y SINERGIA

**Eneatipo**: 3 (El Triunfador)  
**Esencia**: "El éxito con rostro auténtico"  
**Emoción**: Engaño/Vanidad → Verdad

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Verde Esmeralda | `#2D8A6E` | Headers, botones, acentos |
| **Secundario** | Dorado Suave | `#D4AF37` | Highlights, éxitos, premium |
| **Terciario** | Verde Menta | `#A8E6CF` | Fondos de sección |
| **Acento** | Verde Bosque | `#1A5F4A` | Hover, énfasis |
| **Texto** | Gris Carbón | `#2C3E50` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Montserrat* o *Poppins* — Moderna, dinámica
- **Cuerpo**: *Roboto* o *Lato* — Profesional, limpia
- **Énfasis**: *Oswald* — Impacto, fuerza

#### Iconografía

- **Icono principal**: Corona de laurel o Engranaje
- **Símbolos secundarios**: Trofeo, Gráfico ascendente, Estrella
- **Estilo**: Moderno, dinámico, aspiracional

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Éxito, crecimiento, energía │
│                                         │
│  • Líneas dinámicas y ascendentes       │
│  • Elementos geométricos modernos       │
│  • Espacios abiertos y luminosos        │
│  • Fotografía: éxito, logros, equipo    │
│  • Animaciones: rápidas, energéticas    │
│                                         │
└─────────────────────────────────────────┘
```

---

### 🟣 ESTACIÓN 4: DEVIDA ELECCIÓN

**Eneatipo**: 4 (El Individualista)  
**Esencia**: "La vocación que es huella digital"  
**Emoción**: Envidia → Equanimidad

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Violeta | `#6B4C7F` | Headers, botones, acentos |
| **Secundario** | Burdeos | `#722F37` | Profundidad, drama |
| **Terciario** | Lavanda | `#E6E6FA` | Fondos suaves |
| **Acento** | Púrpura Real | `#4B0082` | Hover, énfasis |
| **Texto** | Gris Pizarra | `#2F4F4F` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Cinzel Decorative* o *Cormorant Infant* — Artística, única
- **Cuerpo**: *Merriweather* o *Libre Baskerville* — Literaria, elegante
- **Énfasis**: *Great Vibes* — Expresiva, personal

#### Iconografía

- **Icono principal**: Flor única o Pluma
- **Símbolos secundarios**: Gota de agua, Luna, Mirada
- **Estilo**: Artístico, expresivo, único

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Profundidad, arte, alma     │
│                                         │
│  • Formas fluidas y asimétricas         │
│  • Texturas artísticas (acuarela)       │
│  • Espacios íntimos y profundos         │
│  • Fotografía: artística, emotiva       │
│  • Animaciones: ondulantes, poéticas    │
│                                         │
└─────────────────────────────────────────┘
```

---

### 🔮 ESTACIÓN 5: PATRONES INVISIBLES

**Eneatipo**: 5 (El Investigador)  
**Esencia**: "El código fuente de tu psique"  
**Emoción**: Avaricia → Conocimiento no poseído

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Azul Profundo | `#1E3A5F` | Headers, botones, acentos |
| **Secundario** | Cobre | `#B87333` | Contrastes, tecnología |
| **Terciario** | Azul Eléctrico | `#00BFFF` | Highlights, datos |
| **Acento** | Azul Medianoche | `#191970` | Hover, énfasis |
| **Texto** | Gris Azulado | `#4A5568` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Space Grotesk* o *Rajdhani* — Tecnológica, futurista
- **Cuerpo**: *Inter* o *Fira Sans* — Moderna, técnica
- **Énfasis**: *JetBrains Mono* — Código, precisión

#### Iconografía

- **Icono principal**: Red neuronal o Cristal
- **Símbolos secundarios**: Código, Lupa, Circuito
- **Estilo**: Tecnológico, abstracto, sistémico

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Misterio, análisis, código  │
│                                         │
│  • Líneas de conexión y nodos           │
│  • Elementos de UI tecnológica          │
│  • Espacios oscuros con highlights      │
│  • Fotografía: abstracta, micro         │
│  • Animaciones: precisas, matemáticas   │
│                                         │
└─────────────────────────────────────────┘
```

---

### ⚖️ ESTACIÓN 6: EL CENTRO DE MANDO

**Eneatipo**: 6 (El Leal)  
**Esencia**: "La soberanía de la decisión"  
**Emoción**: Miedo → Coraje

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Gris Carbón | `#36454F` | Headers, botones, acentos |
| **Secundario** | Ámbar | `#FFBF00` | Alertas, decisiones, énfasis |
| **Terciario** | Gris Plata | `#C0C0C0` | Fondos, estructura |
| **Acento** | Gris Hierro | `#434B4D` | Hover, énfasis |
| **Texto** | Negro Suave | `#1C1C1C` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Oswald* o *Bebas Neue* — Autoridad, fuerza
- **Cuerpo**: *Noto Sans* o *PT Sans* — Neutral, confiable
- **Énfasis**: *Roboto Condensed* — Compacta, directa

#### Iconografía

- **Icono principal**: Brújula o Timón
- **Símbolos secundarios**: Escudo, Radar, Ancla
- **Estilo**: Funcional, militar, estructurado

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Autoridad, claridad, orden  │
│                                         │
│  • Líneas fuertes y definidas           │
│  • Elementos de comando y control       │
│  • Espacios organizados, jerárquicos    │
│  • Fotografía: estructuras, seguridad   │
│  • Animaciones: firmes, decididas       │
│                                         │
└─────────────────────────────────────────┘
```

---

### ⚡ ESTACIÓN 7: CONCIENCIA ENERGÉTICA

**Eneatipo**: 7 (El Entusiasta)  
**Esencia**: "La ecología de tu entusiasmo"  
**Emoción**: Gula → Sobriedad gozosa

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Magenta | `#FF00FF` | Headers, botones, acentos |
| **Secundario** | Cian Eléctrico | `#00FFFF` | Energía, movimiento |
| **Terciario** | Amarillo Solar | `#FFD700` | Optimismo, alegría |
| **Acento** | Naranja Neón | `#FF6600` | Hover, CTA |
| **Texto** | Gris Oscuro | `#2D3748` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Fredoka One* o *Baloo* — Divertida, expresiva
- **Cuerpo**: *Varela Round* o *Comfortaa* — Amigable, moderna
- **Énfasis**: *Permanent Marker* — Espontánea, energética

#### Iconografía

- **Icono principal**: Sol radiante o Fuente de luz
- **Símbolos secundarios**: Cohete, Confeti, Relámpago
- **Estilo**: Colorido, dinámico, festivo

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Vitalidad, flujo, alegría   │
│                                         │
│  • Líneas curvas y ondulantes           │
│  • Elementos en movimiento              │
│  • Espacios luminosos y abiertos        │
│  • Fotografía: aventura, experiencias   │
│  • Animaciones: rápidas, vibrantes      │
│                                         │
└─────────────────────────────────────────┘
```

---

### ⚫ ESTACIÓN 8: EL HÁBITO DE LA PERSONALIDAD

**Eneatipo**: 8 (El Desafiador)  
**Esencia**: "La encarnación del poder"  
**Emoción**: Lujuria → Inocencia

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Negro | `#0D0D0D` | Headers, fondos, poder |
| **Secundario** | Oro Quemado | `#8B6914` | Lujo, énfasis |
| **Terciario** | Rojo Oscuro | `#4A0404` | Pasión, intensidad |
| **Acento** | Dorado | `#FFD700` | Hover, premium |
| **Texto** | Blanco Roto | `#F5F5F5` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Abril Fatface* o *Yeseva One* — Poderosa, impactante
- **Cuerpo**: *Karla* o *Work Sans* — Fuerte, legible
- **Énfasis**: *Black Ops One* — Intensa, dominante

#### Iconografía

- **Icono principal**: Nudo celta o Corona
- **Símbolos secundarios**: Puño, León, Trono
- **Estilo**: Poderoso, ancestral, imponente

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Poder, encarnación, fuerza  │
│                                         │
│  • Líneas gruesas y pesadas             │
│  • Elementos de autoridad y poder       │
│  • Espacios dramáticos, contrastados    │
│  • Fotografía: intensa, poderosa        │
│  • Animaciones: contundentes, firmes    │
│                                         │
└─────────────────────────────────────────┘
```

---

### 🟤 ESTACIÓN 9: SABER CONSENTIDO (Matriz)

**Eneatipo**: 9 (El Pacificador)  
**Esencia**: "El mapa que reconcilia el todo"  
**Emoción**: Pereza → Acción correcta

#### Paleta de Colores

| Rol | Color | Hex | Uso |
|-----|-------|-----|-----|
| **Primario** | Sepia | `#704214` | Headers, botones, acentos |
| **Secundario** | Dorado Antiguo | `#C5B358` | Sabiduría, integración |
| **Terciario** | Beige Sabio | `#F5F5DC` | Fondos, armonía |
| **Acento** | Marrón Tierra | `#8B4513` | Hover, énfasis |
| **Texto** | Gris Sepia | `#5C4A3A` | Cuerpo de texto |

#### Tipografía

- **Títulos**: *Cinzel* o *Marcellus* — Clásica, atemporal
- **Cuerpo**: *Crimson Text* o *Literata* — Literaria, sabia
- **Énfasis**: *Uncial Antiqua* — Antigua, mística

#### Iconografía

- **Icono principal**: Mandala o Mapa del tesoro
- **Símbolos secundarios**: Espiral, Árbol, Infinito
- **Estilo**: Sagrado, atemporal, universal

#### Mood Visual

```
┌─────────────────────────────────────────┐
│  SENSACIÓN: Sabiduría, integración, paz │
│                                         │
│  • Formas circulares y espirales        │
│  • Elementos sagrados y atemporales     │
│  • Espacios armoniosos, equilibrados    │
│  • Fotografía: naturaleza, mandalas     │
│  • Animaciones: suaves, meditativas     │
│                                         │
└─────────────────────────────────────────┘
```

---

## 🎭 SISTEMA TIPOGRÁFICO GLOBAL

### Jerarquía de Fuentes

```
┌────────────────────────────────────────────────────────────────┐
│  HIERARCHÍA TIPOGRÁFICA DEL SISTEMA                            │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  H1 - Títulos de Estación                                      │
│  Font: Variable por estación                                   │
│  Size: 48-72px (desktop) / 32-48px (mobile)                    │
│  Weight: Bold / Black                                          │
│  Line-height: 1.1-1.2                                          │
│                                                                │
│  H2 - Títulos de Sección                                       │
│  Font: Variable por estación                                   │
│  Size: 32-48px (desktop) / 24-32px (mobile)                    │
│  Weight: Semi-bold / Bold                                      │
│  Line-height: 1.2-1.3                                          │
│                                                                │
│  H3 - Subtítulos                                               │
│  Font: Variable por estación                                   │
│  Size: 24-32px (desktop) / 20-24px (mobile)                    │
│  Weight: Medium / Semi-bold                                    │
│  Line-height: 1.3-1.4                                          │
│                                                                │
│  Body - Texto principal                                        │
│  Font: Variable por estación                                   │
│  Size: 16-18px (desktop) / 14-16px (mobile)                    │
│  Weight: Regular                                               │
│  Line-height: 1.6-1.8                                          │
│                                                                │
│  Caption - Notas, leyendas                                     │
│  Font: Sans-serif system                                       │
│  Size: 12-14px                                                 │
│  Weight: Regular / Medium                                      │
│  Line-height: 1.4-1.5                                          │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## 🖼️ SISTEMA DE ICONOGRAFÍA

### Biblioteca de Iconos por Estación

| Estación | Icono Principal | Iconos Secundarios | Estilo |
|----------|-----------------|-------------------|--------|
| 1 - Ritmo Justo | Metrónomo | Balanza, Brújula, Regla | Geométrico, preciso |
| 2 - Lazos del Alma | Corazón entrelazado | Manos, Flores, Abrazo | Orgánico, suave |
| 3 - Roles y Sinergia | Corona de laurel | Engranaje, Trofeo, Estrella | Moderno, dinámico |
| 4 - Devida Elección | Flor única | Pluma, Gota, Luna | Artístico, expresivo |
| 5 - Patrones Invisibles | Red neuronal | Cristal, Código, Lupa | Tecnológico, abstracto |
| 6 - Centro de Mando | Brújula | Timón, Escudo, Ancla | Funcional, estructurado |
| 7 - Conciencia Energética | Sol radiante | Fuente, Cohete, Relámpago | Colorido, dinámico |
| 8 - El Hábito | Nudo celta | Corona, Puño, León | Poderoso, ancestral |
| 9 - Saber Consentido | Mandala | Mapa, Espiral, Árbol | Sagrado, atemporal |

---

## 🎨 COHERENCIA VISUAL DEL SISTEMA

### Elementos Unificadores

A pesar de la diversidad cromática, todos los elementos comparten:

1. **Bordes redondeados consistentes**: 4-8px en tarjetas, botones
2. **Sombras sutiles**: Sistema de elevación unificado
3. **Espaciado proporcional**: Sistema de grid de 8px
4. **Animaciones coherentes**: Duración y easing consistentes
5. **Iconografía vectorial**: Todos en SVG, estilo lineal/filled consistente

### Transiciones entre Estaciones

```
┌────────────────────────────────────────────────────────────────┐
│  TRANSICIONES CROMÁTICAS                                       │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  Al navegar entre estaciones conectadas (alas/flechas):        │
│  • Transición de color gradual (300-500ms)                     │
│  • Morphing del icono principal                                │
│  • Animación de líneas de conexión                             │
│                                                                │
│  Ejemplo: Ritmo Justo (1) → Lazos del Alma (2)                │
│  Azul Sereno → Terracota (transición cálida)                   │
│  Metrónomo → Corazón (morphing suave)                          │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
