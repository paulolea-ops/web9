# 🕸️ ARQUITECTURA DE INFORMACIÓN
## Eneagramas: Saber Consentido
### Sistema Web Integral de Autoconocimiento

---

## 📍 MAPA DEL SITIO COMPLETO

```
ENEAGRAMAS: SABER CONSENTIDO (ECOSISTEMA)
│
├── 🏠 PÁGINA MATRIZ (Home)
│   ├── Manifiesto del Sistema
│   ├── Las 9 Estaciones del Ser
│   ├── Test de Orientación de Entrada
│   ├── Recursos Gratuitos
│   ├── Próximos Eventos
│   ├── Comunidad
│   └── Sobre Mí
│
├── 🎯 8 PÁGINAS DE ESPECIALIZACIÓN
│   ├── Estación 1: El Ritmo Justo (Eneatipo 1)
│   ├── Estación 2: Lazos del Alma (Eneatipo 2)
│   ├── Estación 3: Roles y Sinergia (Eneatipo 3)
│   ├── Estación 4: Devida Elección (Eneatipo 4)
│   ├── Estación 5: Patrones Invisibles (Eneatipo 5)
│   ├── Estación 6: El Centro de Mando (Eneatipo 6)
│   ├── Estación 7: Conciencia Energética (Eneatipo 7)
│   └── Estación 8: El Hábito de la Personalidad (Eneatipo 8)
│
├── 📚 SECCIONES TRANSVERSALES
│   ├── Blog/Recursos (filtrable por estación)
│   ├── Tienda/Cursos
│   ├── Comunidad (Foro/Grupo)
│   ├── Calendario de Eventos
│   └── Sobre el Sistema (Metodología)
│
└── 🔧 FUNCIONALIDADES
    ├── Sistema de Diagnóstico
    ├── Motor de Búsqueda
    ├── Área de Miembros
    ├── Reserva de Sesiones
    └── Newsletter/CRM
```

---

## 🧬 ESTRUCTURA DE LAS 9 ESTACIONES

### CONEXIONES ORGÁNICAS DEL ENEAGRAMA

Cada estación se conecta naturalmente con otras 4:
- **2 Alas** (adyacentes numéricamente)
- **2 Flechas** (integración y desintegración)

| Estación | Eneatipo | Alas | Flecha Integración | Flecha Desintegración |
|----------|----------|------|-------------------|----------------------|
| **El Ritmo Justo** | 1 | 9 - 2 | 7 | 4 |
| **Lazos del Alma** | 2 | 1 - 3 | 4 | 8 |
| **Roles y Sinergia** | 3 | 2 - 4 | 6 | 9 |
| **Devida Elección** | 4 | 3 - 5 | 1 | 2 |
| **Patrones Invisibles** | 5 | 4 - 6 | 8 | 7 |
| **El Centro de Mando** | 6 | 5 - 7 | 9 | 3 |
| **Conciencia Energética** | 7 | 6 - 8 | 5 | 1 |
| **El Hábito de la Personalidad** | 8 | 7 - 9 | 2 | 5 |
| **Saber Consentido** | 9 | 8 - 1 | 3 | 6 |

### TRÍADAS DEL SISTEMA

```
    TRIADA DEL INSTINTO (Acción)
         9 - 8 - 1
        /    |    \
       /     |     \
   4 ─┼──────┼──────┼─ 2
      │   TRIADA    │
      │   EMOCIONAL │
      │   (2-3-4)   │
      │             │
   5 ─┼──────┼──────┼─ 7
       \     |     /
        \    |    /
         6 - 7 - 5
      TRIADA MENTAL
```

---

## 🏠 PÁGINA MATRIZ: ENEAGRAMAS: SABER CONSENTIDO

### Propósito
Presentar el sistema completo como un organismo vivo, no como páginas aisladas. Es el portal de entrada que orienta al visitante según su perfil.

### Estructura de Secciones

#### 1. **HERO SECTION: El Mapa que Reconcilia el Todo**
- **Elemento visual**: Mandala animado del Eneagrama con las 9 estaciones
- **Headline**: "Eneagramas: Saber Consentido"
- **Subheadline**: "Un ecosistema integral de autoconocimiento. 9 caminos, 1 verdad: el mapa maestro que revela el 'por qué' detrás de todo."
- **CTA Principal**: "Descubre tu punto de entrada" (lleva al test)
- **CTA Secundario**: "Explora las 9 estaciones" (scroll a la rueda)

#### 2. **MANIFIESTO: Esto No Es Un Test de Personalidad**
- Video o animación explicando la filosofía del sistema
- Texto clave: "El Eneagrama no te pone en una caja. Te muestra la caja en la que ya vives... y las puertas para salir de ella."
- Firma/avatar del creador

#### 3. **LAS 9 ESTACIONES: Rueda Interactiva**
- **Formato**: Mandala interactivo circular
- **Comportamiento**: 
  - Hover: resalta la estación, muestra esencia en tooltip
  - Click: lleva a la página de especialización
- **Visual**: Cada número con su color identitario
- **Leyenda**: Tríadas (Mental, Emocional, Instintiva)

#### 4. **TEST DE ORIENTACIÓN: ¿Por Dónde Empiezo?**
- **Propósito**: No determina eneatipo, sino orienta según dolor/interés actual
- **Preguntas**: 5-7 preguntas clave
- **Resultados**: Recomienda 1-2 estaciones de inicio
- **Embudo**: Captura email antes de mostrar resultado → Lead magnet específico

#### 5. **RECURSOS GRATUITOS**
- Grid de recursos etiquetados por estación
- Filtros: por tríada, por tema, por formato
- CTA a tienda completa

#### 6. **PRÓXIMOS EVENTOS**
- Calendario destacado del mes
- Evento del mes (rotativo por estación)
- Talleres abiertos y cerrados

#### 7. **COMUNIDAD**
- Preview del grupo/comunidad
- Testimonios rotativos
- CTA a unirse

#### 8. **SOBRE MÍ / MI HISTORIA CON EL ENEAGRAMA**
- Foto y bio del creador
- Credenciales y enfoque único
- CTA a consultoría personal

#### 9. **FOOTER: Mapa del Sistema**
- Navegación completa en formato de rueda
- Links legales
- Newsletter
- Redes sociales

---

## 🎯 PÁGINAS DE ESPECIALIZACIÓN (Template Común)

### Estructura Base para Cada Estación (1-8)

#### 1. **HERO ESPECÍFICO DE LA ESTACIÓN**
- **Color de fondo**: Color primario de la estación (gradiente sutil)
- **Icono representativo**: Animado o estático
- **Nombre de la estación**: Grande y prominente
- **Eneatipo anfitrión**: "Para el alma del Tipo X"
- **Esencia**: Frase definitoria (ej: "La acción ética que se vuelve fluidez")
- **CTA**: Lead magnet específico de esta estación

#### 2. **MANIFIESTO DE LA ESTACIÓN**
- Filosofía específica de esta área
- ¿Qué problema resuelve?
- ¿Qué transformación ofrece?
- Video/texto del creador

#### 3. **CONTENIDO PROPIO**
- Artículos destacados
- Recursos descargables
- Podcast/videos específicos
- Cursos relacionados

#### 4. **CÓMO SE CONECTA CON EL SISTEMA** ⭐
Esta es la sección clave que diferencia este proyecto:

**Visual**: Diagrama de conexiones mostrando:
- **Alas**: "Se nutre de..." + "Se aligera con..."
- **Flechas**: "En integración encuentra..." + "En desintegración cae en..."

**Ejemplo para Estación 6 (El Centro de Mando)**:
```
SE NUTRE DE (Ala 5): Patrones Invisibles
"La claridad de la decisión nace del análisis profundo"
→ Link a Estación 5

SE ALIGERA CON (Ala 7): Conciencia Energética  
"La seriedad encuentra alivio en el entusiasmo consciente"
→ Link a Estación 7

EN INTEGRACIÓN: Eneagramas (9)
"La verdadera seguridad es la paz que todo lo abarca"
→ Link a Home/Matriz

EN DESINTEGRACIÓN: Roles y Sinergia (3)
"Cuando la duda se vuelve obsesión por la imagen"
→ Link a Estación 3 (con advertencia)
```

#### 5. **TESTIMONIOS ESPECÍFICOS**
- Casos de uso de esta área
- Etiquetados por eneatipo del testimoniante
- Fotos + texto + video (opcional)

#### 6. **PRODUCTOS/CURSOS DE ESTA ESTACIÓN**
- Ofertas individuales
- Paquetes con estaciones conectadas (alas/flechas)

#### 7. **LLAMADOS A LA ACCIÓN CONTEXTUALES**
- Siguiente paso lógico según el sistema
- "Si estás aquí, quizás también te interese..."

#### 8. **NEWSLETTER ESPECÍFICA**
- "Recursos para [nombre de la estación]"
- Segmentación automática por página de entrada

---

## 🔗 SISTEMA DE NAVEGACIÓN ORGÁNICA

### Navegación Principal (Sticky Header)

```
[Logo]  [Las 9 Estaciones ▼]  [Recursos]  [Tienda]  [Eventos]  [Comunidad]  [Sobre Mí]  [Buscar]  [Mi Cuenta]
```

**Dropdown "Las 9 Estaciones"**:
- Visual: Mini mandala con hover effects
- Agrupado por tríadas
- Indicador visual de "estás aquí"

### Navegación Contextual (En cada página de especialización)

**Barra lateral o sección inferior**:
```
┌─────────────────────────────────────┐
│  CONECTA CON...                     │
├─────────────────────────────────────┤
│  🪽 Alas                            │
│  [Estación X] ← [ESTÁS AQUÍ] → [Estación Y]  │
│                                     │
│  🔄 Flechas                         │
│  Integración: [Estación Z]          │
│  Desintegración: [Estación W]       │
└─────────────────────────────────────┘
```

### Breadcrumbs Sistémicos

```
Inicio > Tríada [Mental/Emocional/Instintiva] > [Nombre de Estación]
```

### Mapa del Sistema (Página dedicada)

- Visualización interactiva completa del Eneagrama
- Click en cada número lleva a su estación
- Líneas animadas mostrando conexiones
- Leyenda explicativa

---

## 📊 FLUJOS DE NAVEGACIÓN POR PERFIL DE USUARIO

### Flujo 1: "No sé nada del Eneagrama"
```
Home → Test de Orientación → Resultado → Estación recomendada → Lead magnet → Email capturado → Embudo de nurturing
```

### Flujo 2: "Sé mi eneatipo"
```
Home → Rueda interactiva → Click en su número → Estación correspondiente → Contenido específico → Comunidad
```

### Flujo 3: "Busco solución a un problema específico"
```
Home/Blog → Artículo → Etiquetas → Estaciones relacionadas → Producto/Curso → Compra
```

### Flujo 4: "Ya soy parte de la comunidad"
```
Login → Área de miembros → Contenido exclusivo → Eventos → Reserva
```

---

## 🏷️ TAXONOMÍA DE CONTENIDOS

### Sistema de Etiquetado Múltiple

Cada contenido puede tener:
- **Estación primaria**: A qué estación pertenece principalmente
- **Estaciones secundarias**: Con qué otras estaciones se conecta
- **Tríada**: Mental / Emocional / Instintiva
- **Tipo de contenido**: Artículo / Video / Podcast / PDF / Curso
- **Nivel**: Introductorio / Intermedio / Avanzado
- **Eneatipo objetivo**: Puede ser específico o "todos"

### Ejemplo de Etiquetado

Artículo: "Cómo la perfección bloquea tu creatividad"
- Estación primaria: El Ritmo Justo (1)
- Estaciones secundarias: Devida Elección (4), Patrones Invisibles (5)
- Tríada: Instintiva + Emocional
- Tipo: Artículo
- Nivel: Intermedio
- Eneatipo: 1, 4, 5 (pero útil para todos)

---

## 📱 ARQUITECTURA RESPONSIVE

### Desktop (>1024px)
- Navegación completa visible
- Rueda del Eneagrama interactiva a tamaño completo
- Sidebars con navegación contextual
- Múltiples columnas en grids

### Tablet (768px - 1024px)
- Navegación colapsada en hamburguesa
- Rueda simplificada o lista
- Sidebars convertidos a secciones inferiores
- 2 columnas en grids

### Mobile (<768px)
- Navegación móvil prioritaria
- Rueda convertida en carrusel o lista vertical
- Contenido en una columna
- Test de orientación simplificado
- CTAs prominentes y accesibles

---

## 🎯 ESTRATEGIA DE URLs

### Estructura de URLs SEO-friendly

```
/                                      → Home (Matriz)
/estaciones/el-ritmo-justo             → Estación 1
/estaciones/lazos-del-alma             → Estación 2
/estaciones/roles-y-sinergia           → Estación 3
/estaciones/devida-eleccion            → Estación 4
/estaciones/patrones-invisibles        → Estación 5
/estaciones/el-centro-de-mando         → Estación 6
/estaciones/conciencia-energetica      → Estación 7
/estaciones/el-habito-de-la-personalidad → Estación 8

/recursos                              → Blog/Recursos
/recursos/[categoria]                  → Filtrado por categoría
/recursos/[slug-articulo]              → Artículo individual

/tienda                                → Tienda principal
/tienda/[categoria]                    → Categorías de productos
/tienda/[slug-producto]                → Producto individual

/eventos                               → Calendario
/eventos/[slug-evento]                 → Evento individual

/comunidad                             → Página de comunidad
/comunidad/foro                        → Foro/Grupo

/sobre-mi                              → Sobre el creador
/sobre-el-sistema                      → Metodología

/mi-cuenta                             → Área de miembros
/mi-cuenta/cursos                      → Mis cursos
/mi-cuenta/perfil                      → Perfil

/test-orientacion                      → Test de entrada
/mapa-del-sistema                      → Visualización completa
```

---

## 📈 PRÓXIMOS PASOS

1. **Wireframing** de cada tipo de página
2. **Diseño de identidad visual** por estación
3. **Definición técnica** de stack y funcionalidades
4. **Estrategia de contenido** inicial
5. **Plan de lanzamiento** por fases

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
