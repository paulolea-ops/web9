# 🕸️ ENEAGRAMAS: SABER CONSENTIDO
## Documentación Completa del Sistema Web

---

## 📋 ÍNDICE DE DOCUMENTOS

Esta documentación contiene **8 documentos detallados** que cubren todos los aspectos del diseño y desarrollo del ecosistema web "Eneagramas: Saber Consentido".

### 📖 Documentos Principales

| # | Documento | Descripción | Prioridad |
|---|-----------|-------------|-----------|
| 1 | **[Arquitectura de Información](01-arquitectura-informacion.md)** | Mapa del sitio completo, jerarquías, flujos de navegación | ⭐⭐⭐ |
| 2 | **[Sistema de Navegación Orgánica](02-sistema-navegacion-organico.md)** | Conexiones del Eneagrama (alas y flechas) | ⭐⭐⭐ |
| 3 | **[Identidad Visual por Estación](03-identidad-visual-estaciones.md)** | Paletas de color, tipografías, iconografía | ⭐⭐⭐ |
| 4 | **[Estructura de Páginas](04-estructura-paginas.md)** | Wireframes detallados de Home y templates | ⭐⭐⭐ |
| 5 | **[Secciones Transversales](05-secciones-transversales.md)** | Blog, tienda, comunidad, eventos | ⭐⭐ |
| 6 | **[Stack Tecnológico](06-stack-tecnologico.md)** | Herramientas, plugins, integraciones | ⭐⭐ |
| 7 | **[Estrategia de Conversión](07-estrategia-conversion.md)** | Embudos, lead magnets, ofertas | ⭐⭐ |
| 8 | **[Resumen Ejecutivo](08-resumen-ejecutivo.md)** | Síntesis de todo el proyecto | ⭐⭐⭐ |

---

## 🎯 RESUMEN DEL PROYECTO

**Eneagramas: Saber Consentido** es un ecosistema web integral de autoconocimiento basado en el Eneagrama, compuesto por:

- **1 Página Matriz** (Home - Estación 9)
- **8 Páginas de Especialización** (Estaciones 1-8)
- **Sistema de navegación orgánica** basado en alas y flechas del Eneagrama
- **Identidad visual única** por cada estación
- **Funcionalidades avanzadas**: test de orientación, tienda, membresía, comunidad

### Las 9 Estaciones del Ser

| # | Nombre | Eneatipo | Color | Esencia |
|---|--------|----------|-------|---------|
| 1 | El Ritmo Justo | 1 | 🔵 Azul Sereno | La acción ética que se vuelve fluidez |
| 2 | Lazos del Alma | 2 | 🟠 Terracota | El arte consciente del vínculo |
| 3 | Roles y Sinergia | 3 | 🟢 Verde Esmeralda | El éxito con rostro auténtico |
| 4 | Devida Elección | 4 | 🟣 Violeta | La vocación que es huella digital |
| 5 | Patrones Invisibles | 5 | 🔮 Azul Profundo | El código fuente de tu psique |
| 6 | El Centro de Mando | 6 | ⚖️ Gris Carbón | La soberanía de la decisión |
| 7 | Conciencia Energética | 7 | ⚡ Magenta | La ecología de tu entusiasmo |
| 8 | El Hábito de la Personalidad | 8 | ⚫ Negro | La encarnación del poder |
| 9 | **Saber Consentido** | 9 | 🟤 Sepia | El mapa que reconcilia el todo |

---

## 🚀 CÓMO USAR ESTA DOCUMENTACIÓN

### Para Desarrolladores
1. Comenzar con **[Arquitectura de Información](01-arquitectura-informacion.md)**
2. Revisar **[Stack Tecnológico](06-stack-tecnologico.md)**
3. Consultar **[Estructura de Páginas](04-estructura-paginas.md)** para implementación

### Para Diseñadores
1. Comenzar con **[Identidad Visual](03-identidad-visual-estaciones.md)**
2. Revisar **[Estructura de Páginas](04-estructura-paginas.md)**
3. Consultar **[Sistema de Navegación](02-sistema-navegacion-organico.md)**

### Para Estrategas de Marketing
1. Comenzar con **[Estrategia de Conversión](07-estrategia-conversion.md)**
2. Revisar **[Resumen Ejecutivo](08-resumen-ejecutivo.md)**
3. Consultar **[Secciones Transversales](05-secciones-transversales.md)**

### Para el Cliente/Propietario
1. Leer **[Resumen Ejecutivo](08-resumen-ejecutivo.md)** primero
2. Revisar **[Arquitectura de Información](01-arquitectura-informacion.md)**
3. Consultar **[Estrategia de Conversión](07-estrategia-conversion.md)**

---

## 📊 ENTREGABLES INCLUIDOS

✅ **Arquitectura de información completa**
- Mapa del sitio con 9 páginas principales
- Jerarquías y flujos de navegación
- Estructura de URLs SEO-friendly

✅ **Diseño de páginas detallado**
- Wireframes descriptivos de Home
- Template reusable para 8 estaciones
- Estructura de secciones transversales

✅ **Sistema de navegación orgánico**
- Conexiones de alas y flechas para cada estación
- Menú tipo mandala interactivo
- Navegación contextual

✅ **Identidad visual completa**
- Paleta cromática para cada estación
- Tipografías específicas
- Iconografía representativa

✅ **Recomendaciones técnicas**
- Stack tecnológico detallado
- Plugins necesarios
- Presupuesto estimado

✅ **Estrategia de contenido**
- Lead magnets por estación
- Embudos automatizados
- Ofertas combinadas

✅ **Plan de implementación**
- Calendario de lanzamiento
- Checklist de funcionalidades
- Métricas clave (KPIs)

---

## 💰 PRESUPUESTO ESTIMADO

### Opción MVP (Mínimo Viable)
- **Hosting**: $180/año
- **Plugins**: $475/año
- **Total**: **~$655/año**

### Opción Completa (Recomendada)
- **Hosting**: $420/año
- **Plugins**: $891/año
- **Total**: **~$1,311/año**

---

## 📅 CALENDARIO DE LANZAMIENTO

| Fase | Duración | Enfoque |
|------|----------|---------|
| **Pre-lanzamiento** | Mes 1 | Sitio base + 3 estaciones |
| **Lanzamiento suave** | Mes 2 | Beta + feedback |
| **Lanzamiento público** | Mes 3 | 9 estaciones + ads |
| **Escalamiento** | Mes 4+ | Optimización + crecimiento |

---

## 📞 NOTAS IMPORTANTES

### Sobre el Sistema de Navegación
La característica más distintiva de este proyecto es el **sistema de navegación orgánica** que refleja las conexiones naturales del Eneagrama. Cada página de estación debe incluir obligatoriamente la sección "Cómo se conecta con el sistema" mostrando sus alas y flechas.

### Sobre la Identidad Visual
Cada estación tiene su propia identidad visual, pero todas deben sentirse parte de la misma familia. Los elementos unificadores (bordes, sombras, espaciado) son tan importantes como los elementos diferenciadores (colores, tipografías).

### Sobre la Experiencia Móvil
Se estima que el 60%+ del tráfico vendrá de dispositivos móviles. El mandala debe simplificarse en móvil, manteniendo la navegación intuitiva.

---

## 🎯 PRÓXIMOS PASOS

1. [ ] Revisar y aprobar documentación
2. [ ] Priorizar funcionalidades para MVP
3. [ ] Seleccionar stack tecnológico final
4. [ ] Contratar desarrollador o agencia
5. [ ] Crear contenido inicial
6. [ ] Establecer presencia en redes
7. [ ] Construir lista de espera
8. [ ] Lanzar versión beta

---

## 📚 RECURSOS ADICIONALES

### Sobre el Eneagrama
- [International Enneagram Association](https://www.internationalenneagram.org/)
- [Enneagram Institute](https://www.enneagraminstitute.com/)

### Sobre Diseño Web
- [Elementor Documentation](https://elementor.com/help/)
- [WordPress Codex](https://codex.wordpress.org/)

### Sobre Marketing Digital
- [HubSpot Academy](https://academy.hubspot.com/)
- [ConvertKit Resources](https://convertkit.com/resources)

---

> "El mapa no es el territorio, pero un buen mapa puede cambiar tu relación con el territorio para siempre."

---

*Documentación creada para Eneagramas: Saber Consentido*  
*Fecha: Febrero 2024*
