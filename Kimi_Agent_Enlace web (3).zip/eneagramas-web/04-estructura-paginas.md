# 📄 ESTRUCTURA DE PÁGINAS
## Wireframes Descriptivos Detallados

---

## 🏠 PÁGINA MATRIZ: HOME (Eneagramas: Saber Consentido)

### Propósito
Presentar el ecosistema completo, orientar al visitante y convertirlo en miembro de la comunidad.

---

### SECCIÓN 1: HERO

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  [NAV: Logo | Las 9 Estaciones ▼ | Recursos | Tienda | Eventos | Comunidad] │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                                                                             │
│                         ╭───────────────╮                                   │
│                        ╱    [ICONO      ╲                                  │
│                       │    MANDALA 9]    │                                  │
│                        ╲                 ╱                                  │
│                         ╰───────────────╯                                   │
│                                                                             │
│              E N E A G R A M A S :  S A B E R  C O N S E N T I D O          │
│                                                                             │
│     "Un ecosistema integral de autoconocimiento. 9 caminos, 1 verdad:       │
│              el mapa maestro que revela el 'por qué' detrás de todo."       │
│                                                                             │
│                                                                             │
│         [🎯 Descubre tu punto de entrada]    [🌐 Explora las 9 estaciones]  │
│                                                                             │
│                                                                             │
│     ╭───╮  ╭───╮  ╭───╮  ╭───╮  ╭───╮  ╭───╮  ╭───╮  ╭───╮  ╭───╮         │
│     │ 1 │  │ 2 │  │ 3 │  │ 4 │  │ 9 │  │ 5 │  │ 6 │  │ 7 │  │ 8 │         │
│     ╰───╯  ╰───╯  ╰───╯  ╰───╯  ╰───╯  ╰───╯  ╰───╯  ╰───╯  ╰───╯         │
│                                                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Elementos**:
- **Background**: Gradiente sutil sepia/dorado o imagen de mandala
- **Animación**: Mandala girando lentamente, números del 1-9 con hover effects
- **CTA Primario**: Lleva al Test de Orientación
- **CTA Secundario**: Scroll suave a la sección de Las 9 Estaciones

---

### SECCIÓN 2: MANIFIESTO

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  ╭────────────────────────────────╮  ╭────────────────────────────────╮     │
│  │                                │  │                                │     │
│  │   [VIDEO/FOTO DEL CREADOR]     │  │   E S T O  N O  E S            │     │
│  │                                │  │   U N  T E S T                 │     │
│  │   [Botón de play]              │  │   D E  P E R S O N A L I D A D │     │
│  │                                │  │                                │     │
│  ╰────────────────────────────────╯  │   "El Eneagrama no te pone en   │     │
│                                      │    una caja. Te muestra la caja │     │
│                                      │    en la que ya vives... y las  │     │
│                                      │    puertas para salir de ella." │     │
│                                      │                                │     │
│                                      │   ───                          │     │
│                                      │   [Tu Nombre]                  │     │
│                                      │   Facilitador de Eneagrama     │     │
│                                      │                                │     │
│                                      ╰────────────────────────────────╯     │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  "Saber Consentido no es acumular información sobre tu tipo.        │   │
│  │   Es consentir el mapa completo: tus alas, tus flechas,             │   │
│  │   tus tríadas, tu camino de integración."                           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Elementos**:
- Video de bienvenida o foto del creador
- Quote destacado
- CTA: "Conoce mi historia con el Eneagrama" → Sobre Mí

---

### SECCIÓN 3: LAS 9 ESTACIONES (Rueda Interactiva)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│              L A S   9   E S T A C I O N E S   D E L   S E R                │
│                                                                             │
│     "Cada una es una puerta. Todas conducen al mismo santuario:             │
│                        el conocimiento de ti mismo."                        │
│                                                                             │
│                                                                             │
│                         ╭───────────╮                                       │
│                        ╱    [9]     ╲                                      │
│                       │   SABER      │                                      │
│                       │ CONSENTIDO   │                                      │
│                        ╲             ╱                                      │
│                         ╰─────┬─────╯                                       │
│                               │                                             │
│           ╭──────────╮   ╭────┴────╮   ╭──────────╮                        │
│          ╱    [8]    ╲ ╱   [1]     ╲ ╱    [2]     ╲                       │
│         │   HÁBITO    │ │   RITMO   │ │   LAZOS    │                       │
│         │             │ │   JUSTO   │ │   ALMA     │                       │
│          ╲           ╱   ╲         ╱   ╲           ╱                       │
│           ╰─────────╯     ╰───────╯     ╰─────────╯                        │
│                                                                             │
│           ╭──────────╮   ╭──────────╮   ╭──────────╮                       │
│          ╱    [7]    ╲ ╱    [6]     ╲ ╱    [3]     ╲                      │
│         │ CONCIENCIA  │ │  CENTRO   │ │   ROLES    │                       │
│         │ ENERGÉTICA  │ │   MANDO   │ │  SINERGIA  │                       │
│          ╲           ╱   ╲         ╱   ╲           ╱                       │
│           ╰─────────╯     ╰───────╯     ╰─────────╯                        │
│                                                                             │
│                         ╭───────────╮                                       │
│                        ╱    [5]     ╲                                      │
│                       │  PATRONES   │                                       │
│                       │ INVISIBLES  │                                       │
│                        ╲    [4]     ╱                                      │
│                         ╰───────────╯                                       │
│                          DEVIDA                                             │
│                          ELECCIÓN                                           │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  🧠 TRÍADA MENTAL (5-6-7)  │  ❤️ EMOCIONAL (2-3-4)  │  ⚡ INSTINTIVA │   │
│  │     Pensamiento            │     Sentimiento         │    (8-9-1)    │   │
│  │     Miedo → Confianza      │     Vergüenza → Amor    │  Ira → Paz    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Interacciones**:
- **Hover sobre número**: Resalta, muestra nombre completo y esencia
- **Click**: Navega a la estación
- **Hover sobre tríada**: Resalta los 3 números de esa tríada

---

### SECCIÓN 4: TEST DE ORIENTACIÓN

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                                                                             │
│           ¿ P O R   D Ó N D E   E M P I E Z O ?                             │
│                                                                             │
│     "No necesitas saber tu tipo de Eneagrama. Solo necesitas               │
│              honestidad sobre dónde te duele ahora."                        │
│                                                                             │
│                                                                             │
│     ┌─────────────────────────────────────────────────────────────────┐    │
│     │                                                                 │    │
│     │   PREGUNTA 1/5                                                  │    │
│     │                                                                 │    │
│     │   "¿Qué área de tu vida te genera más fricción actualmente?"    │    │
│     │                                                                 │    │
│     │   ○ Mi relación con el tiempo y la organización                 │    │
│     │   ○ Mis relaciones personales y vínculos                        │    │
│     │   ○ Mi carrera y reconocimiento profesional                     │    │
│     │   ○ Mi sentido de propósito e identidad                         │    │
│     │   ○ Mi necesidad de entender cómo funciono                      │    │
│     │   ○ Mi capacidad de tomar decisiones                            │    │
│     │   ○ Mi relación con el placer y la moderación                   │    │
│     │   ○ Mi forma de usar el poder y la autoridad                    │    │
│     │   ○ Mi conexión con el todo y la paz interior                   │    │
│     │                                                                 │    │
│     │   [Continuar →]                                                 │    │
│     │                                                                 │    │
│     └─────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│     💡 Este test no determina tu tipo de Eneagrama. Te orienta hacia        │
│        la estación que puede acompañarte mejor en este momento.             │
│                                                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Flujo del Test**:
1. 5-7 preguntas sobre dolor/interés actual
2. Al finalizar, pide email para mostrar resultado
3. Resultado: 1-2 estaciones recomendadas con explicación
4. Lead magnet específico para la estación recomendada

---

### SECCIÓN 5: RECURSOS GRATUITOS

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    R E C U R S O S   G R A T U I T O S                      │
│                                                                             │
│  [🔍 Buscar recursos...]  [Filtrar por estación ▼]  [Formato ▼]            │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [IMAGEN]        │  │ [IMAGEN]        │  │ [IMAGEN]        │             │
│  │                 │  │                 │  │                 │             │
│  │ TAG: Estación 1 │  │ TAG: Estación 4 │  │ TAG: Estación 6 │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ Guía: El arte   │  │ Ebook: Encontrar│  │ Checklist:      │             │
│  │ de la           │  │ tu voz en medio │  │ Decisiones      │             │
│  │ organización    │  │ del ruido       │  │ conscientes     │             │
│  │ consciente      │  │                 │  │                 │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ [Descargar PDF] │  │ [Descargar PDF] │  │ [Descargar PDF] │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [IMAGEN]        │  │ [IMAGEN]        │  │ [IMAGEN]        │             │
│  │                 │  │                 │  │                 │             │
│  │ TAG: Estación 3 │  │ TAG: Estación 7 │  │ TAG: Todas      │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ Video: Éxito    │  │ Podcast: La     │  │ Mapa: Las 9     │             │
│  │ sin sacrificar  │  │ ecología del    │  │ estaciones      │             │
│  │ tu alma         │  │ entusiasmo      │  │ interactivo     │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ [Ver video]     │  │ [Escuchar]      │  │ [Explorar]      │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│                    [Ver todos los recursos →]                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### SECCIÓN 6: PRÓXIMOS EVENTOS

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                       P R Ó X I M O S   E V E N T O S                       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   EVENTO DESTACADO DEL MES                                          │   │
│  │                                                                     │   │
│  │   ╭──────────────╮                                                  │   │
│  │   │              │  "El Centro de Mando:                           │   │
│  │   │   [FOTO]     │   Taller de toma de decisiones conscientes"     │   │
│  │   │              │                                                  │   │
│  │   │  📅 15 Mar   │  📍 Online en vivo  │  🎫 20 plazas             │   │
│  │   ╰──────────────╯                                                  │   │
│  │                                                                     │   │
│  │   [Reservar plaza →]                                                │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Próximos talleres:                                                         │
│                                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │ 📅 22 Mar   │  │ 📅 29 Mar   │  │ 📅 05 Abr   │  │ 📅 12 Abr   │        │
│  │ Estación 3  │  │ Estación 7  │  │ Estación 2  │  │ Estación 5  │        │
│  │ [Ver más]   │  │ [Ver más]   │  │ [Ver más]   │  │ [Ver más]   │        │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                                             │
│                    [Ver calendario completo →]                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### SECCIÓN 7: COMUNIDAD

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                           C O M U N I D A D                                 │
│                                                                             │
│     "El autoconocimiento no es un camino solitario.                         │
│      Únete a quienes también buscan comprenderse."                          │
│                                                                             │
│  ╭──────────────────────────────────────────────────────────────────────╮  │
│  │                                                                      │  │
│  │  "Encontré en esta comunidad un espacio donde finalmente             │  │
│  │   pude hablar de mis patrones sin vergüenza. El mapa del             │  │
│  │   Eneagrama me dio lenguaje para lo que sentía."                     │  │
│  │                                                                      │  │
│  │   ─── María G. │ Tipo 4                                              │  │
│  │                                                                      │  │
│  ╰──────────────────────────────────────────────────────────────────────╯  │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │   👥 +500       │  │   📚 +50        │  │   🎯 +20        │             │
│  │   miembros      │  │   recursos      │  │   eventos/año   │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│     [💬 Unirme al grupo de Facebook]    [💬 Unirme al Discord]             │
│                                                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### SECCIÓN 8: FOOTER

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  M A P A   D E L   S I S T E M A                                            │
│                                                                             │
│         [9]                                                                 │
│          │                                                                  │
│    [8] ──┼── [1] ── [2]                                                     │
│          │                                                                  │
│    [7] ──┼── [6] ── [3]                                                     │
│          │                                                                  │
│         [5] ── [4]                                                          │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  LAS 9 ESTACIONES      RECURSOS           TIENDA           CONECTA          │
│  ─────────────────     ─────────          ──────           ───────          │
│  • El Ritmo Justo      • Blog             • Cursos         • Sobre mí       │
│  • Lazos del Alma      • Podcast          • Sesiones       • Contacto       │
│  • Roles y Sinergia    • Ebooks           • Membresía      • Newsletter     │
│  • Devida Elección     • Videos                                          │
│  • Patrones Invisibles                                                    │
│  • El Centro de Mando                                                     │
│  • Conciencia Energética                                                  │
│  • El Hábito                                                              │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  [Logo]  Eneagramas: Saber Consentido © 2024                               │
│                                                                             │
│  [📘] [📸] [🐦] [▶️]     [Términos] [Privacidad] [Cookies]                 │
│                                                                             │
│  Hecho con 💜 para quienes buscan comprenderse                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🎯 TEMPLATE: PÁGINA DE ESPECIALIZACIÓN

Este template se replica para las 8 estaciones (1-8), cambiando colores, iconos y contenido específico.

### Estructura Base

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [NAV con color de la estación]                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  HERO CON COLOR PRIMARIO DE LA ESTACIÓN                                     │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│                         ╭───────────────╮                                   │
│                        ╱   [ICONO       ╲                                  │
│                       │    ESTACIÓN]     │                                  │
│                        ╲                 ╱                                  │
│                         ╰───────────────╯                                   │
│                                                                             │
│              E L   R I T M O   J U S T O   (Ejemplo Estación 1)             │
│                                                                             │
│                    "La acción ética que se vuelve fluidez"                  │
│                                                                             │
│                         Para el alma del Tipo 1                             │
│                                                                             │
│              [📥 Descargar guía gratuita de esta estación]                  │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   2:   M A N I F I E S T O   D E   L A   E S T A C I Ó N     │
│                                                                             │
│  ¿Qué es El Ritmo Justo?                                                    │
│                                                                             │
│  [Texto explicativo de la filosofía específica de esta estación]            │
│                                                                             │
│  ¿Qué problema resuelve?                                                    │
│  • La rigidez que paraliza                                                  │
│  • La crítica excesiva                                                      │
│  • La tensión entre el deber y el deseo                                     │
│                                                                             │
│  ¿Qué transformación ofrece?                                                │
│  • De la perfección a la excelencia consciente                              │
│  • Del deber al deseo alineado                                              │
│  • De la tensión a la fluidez                                               │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   3:   C O N T E N I D O   P R O P I O                       │
│                                                                             │
│  Artículos destacados de esta estación:                                     │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ [IMG]           │  │ [IMG]           │  │ [IMG]           │             │
│  │                 │  │                 │  │                 │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ "Cuando la      │  │ "La belleza de  │  │ "Perfeccionismo │             │
│  │  perfección     │  │  lo suficiente- │  │  vs. Excelencia │             │
│  │  bloquea"       │  │  mente bueno"   │  │  consciente"    │             │
│  ├─────────────────┤  ├─────────────────┤  ├─────────────────┤             │
│  │ [Leer más →]    │  │ [Leer más →]    │  │ [Leer más →]    │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                             │
│  Recursos descargables:                                                     │
│  • [📄 Checklist: La organización consciente]                               │
│  • [📄 Guía: De la crítica a la compasión]                                  │
│  • [🎧 Meditación: Soltar el control]                                       │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   4:   C Ó M O   S E   C O N E C T A   (⭐ CLAVE)            │
│                                                                             │
│  ╔═══════════════════════════════════════════════════════════════════════╗ │
│  ║  🌟 EL RITMO JUSTO NO EXISTE EN AISLAMIENTO                           ║ │
│  ╠═══════════════════════════════════════════════════════════════════════╣ │
│  ║                                                                       ║ │
│  ║  🪽 ALAS - Los matices de tu justicia                                 ║ │
│  ║                                                                       ║ │
│  ║  ┌─────────────┐         ┌─────────────┐                             ║ │
│  ║  │   [ICON 9]  │ ←─────→ │   [ICON 2]  │                             ║ │
│  ║  │   SABER     │   [1]   │   LAZOS     │                             ║ │
│  ║  │ CONSENTIDO  │   TÚ    │   ALMA      │                             ║ │
│  ║  │             │         │             │                             ║ │
│  ║  │ "La paz que │         │ "El amor    │                             ║ │
│  ║  │ fundamenta" │         │ que suaviza"│                             ║ │
│  ║  └─────────────┘         └─────────────┘                             ║ │
│  ║                                                                       ║ │
│  ║  🔄 FLECHAS - Tus caminos de transformación                           ║ │
│  ║                                                                       ║ │
│  ║  ⬆️ INTEGRACIÓN:                                                      ║ │
│  ║  ┌─────────────────────────────────────────────────────────────┐     ║ │
│  ║  │  [ICON 7] CONCIENCIA ENERGÉTICA                             │     ║ │
│  ║  │  "Cuando sueltas el control, encuentras la alegría"         │     ║ │
│  ║  │  [Explorar esta conexión →]                                 │     ║ │
│  ║  └─────────────────────────────────────────────────────────────┘     ║ │
│  ║                                                                       ║ │
│  ║  ⬇️ DESINTEGRACIÓN (zona de alerta):                                  ║ │
│  ║  ┌─────────────────────────────────────────────────────────────┐     ║ │
│  ║  │  [ICON 4] DEVIDA ELECCIÓN                                   │     ║ │
│  ║  │  "Cuidado: la crítica excesiva te hunde en la envidia"      │     ║ │
│  ║  │  [Reconocer este patrón →]                                  │     ║ │
│  ║  └─────────────────────────────────────────────────────────────┘     ║ │
│  ║                                                                       ║ │
│  ╚═══════════════════════════════════════════════════════════════════════╝ │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   5:   T E S T I M O N I O S                                 │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  "El Ritmo Justo me ayudó a ver que mi búsqueda de perfección       │   │
│  │   no era virtud, era prisión. Hoy trabajo desde la excelencia,      │   │
│  │   no desde la exigencia."                                           │   │
│  │                                                                     │   │
│  │   ─── Carlos M. │ Tipo 1 │ Coach                                    │   │
│  │                                                                     │   │
│  │   [🎥 Ver video testimonio]                                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   6:   P R O D U C T O S   Y   C U R S O S                   │
│                                                                             │
│  De esta estación:                                                          │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │ [IMG]           │  │ [IMG]           │                                   │
│  │ CURSO           │  │ SESIÓN          │                                   │
│  │ "El Ritmo       │  │ "Consulta       │                                   │
│  │  Justo:         │  │  personalizada  │                                   │
│  │  Organización   │  │  de Ritmo       │                                   │
│  │  consciente"    │  │  Justo"         │                                   │
│  │                 │  │                 │                                   │
│  │ $97 │ [Ver →]   │  │ $150 │ [Ver →]  │                                   │
│  └─────────────────┘  └─────────────────┘                                   │
│                                                                             │
│  Paquetes combinados:                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  📦 COLECCIÓN TRÍADA INSTINTIVA (1-8-9)                             │   │
│  │  Ritmo Justo + Hábito + Saber Consentido                            │   │
│  │  [Ver paquete →]                                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  📦 VIAJE DE ALAS: 1 → 9 → 2                                        │   │
│  │  Ritmo Justo + Saber Consentido + Lazos del Alma                    │   │
│  │  [Ver paquete →]                                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   7:   S I G U I E N T E   P A S O                           │
│                                                                             │
│  Si te resonó El Ritmo Justo, quizás también te interese:                   │
│                                                                             │
│  ┌─────────────────┐  ┌─────────────────┐                                   │
│  │ [ICON 7]        │  │ [ICON 9]        │                                   │
│  │ CONCIENCIA      │  │ SABER           │                                   │
│  │ ENERGÉTICA      │  │ CONSENTIDO      │                                   │
│  │                 │  │                 │                                   │
│  │ Tu camino de    │  │ El todo que     │                                   │
│  │ integración     │  │ lo abarca       │                                   │
│  │                 │  │                 │                                   │
│  │ [Explorar →]    │  │ [Explorar →]    │                                   │
│  └─────────────────┘  └─────────────────┘                                   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  S E C C I Ó N   8:   N E W S L E T T E R                                   │
│                                                                             │
│  Recursos exclusivos para El Ritmo Justo                                    │
│                                                                             │
│  [📧 Tu email... ] [Suscribirme]                                            │
│                                                                             │
│  Recibirás: artículos, meditaciones y recursos específicos para             │
│  quienes transitan la búsqueda de la perfección consciente.                 │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  [FOOTER con color de la estación]                                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📋 CHECKLIST DE ELEMENTOS POR PÁGINA

### Página Matriz (Home)
- [ ] Hero con mandala y CTAs
- [ ] Manifiesto del sistema
- [ ] Rueda interactiva de las 9 estaciones
- [ ] Test de orientación
- [ ] Recursos gratuitos (grid filtrable)
- [ ] Próximos eventos
- [ ] Comunidad y testimonios
- [ ] Footer con mapa del sistema

### Página de Especialización (1-8)
- [ ] Hero con color/icono específico
- [ ] Manifiesto de la estación
- [ ] Contenido propio (artículos, recursos)
- [ ] Sección "Cómo se conecta" (alas y flechas) ⭐
- [ ] Testimonios específicos
- [ ] Productos/cursos de esta estación
- [ ] Paquetes combinados
- [ ] Siguiente paso sugerido
- [ ] Newsletter específica
- [ ] Footer coherente

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
