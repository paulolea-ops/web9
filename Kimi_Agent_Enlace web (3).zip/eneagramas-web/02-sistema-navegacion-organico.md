# 🔗 SISTEMA DE NAVEGACIÓN ORGÁNICA
## Conexiones Vivas del Eneagrama

---

## 🌐 FILOSOFÍA DE NAVEGACIÓN

> "El Eneagrama no es una rueda estática. Es un sistema vivo de energías que fluyen, se nutren y se transforman. La navegación de este sitio debe reflejar esa organicidad."

### Principios Fundamentales

1. **No hay páginas aisladas**: Cada estación está conectada con otras 4
2. **Las conexiones tienen significado**: No son links aleatorios, reflejan alas y flechas
3. **El usuario fluye, no salta**: Las transiciones entre páginas deben sentirse naturales
4. **Cada entrada es válida**: Múltiples puertas de entrada al mismo ecosistema

---

## 🕸️ MAPA DE CONEXIONES DETALLADO

### Visualización Completa de Conexiones

```
                         ╭──────────────╮
                         │   ESTACIÓN   │
                         │      9       │
                         │   (Matriz)   │
                         ╰──────┬───────╯
                                │
           ╭────────────────────┼────────────────────╮
           │                    │                    │
           ▼                    ▼                    ▼
    ╭──────────────╮      ╭──────────────╮      ╭──────────────╮
    │  ESTACIÓN 8  │◄────►│  ESTACIÓN 1  │◄────►│  ESTACIÓN 2  │
    │   Tipo 8     │ Alas  │   Tipo 1     │ Alas  │   Tipo 2     │
    ╰──────┬───────╯      ╰──────┬───────╯      ╰──────┬───────╯
           │                    │                    │
           │            ╭───────┴───────╮            │
           │            │               │            │
           ▼            ▼               ▼            ▼
    ╭──────────────╮  ╭──────────╮  ╭──────────╮  ╭──────────────╮
    │  ESTACIÓN 7  │  │INTEGRACIÓN│  │DESINTEG. │  │  ESTACIÓN 3  │
    │   Tipo 7     │  │    7     │  │    4     │  │   Tipo 3     │
    ╰──────┬───────╯  ╰──────────╯  ╰──────────╯  ╰──────┬───────╯
           │                                              │
           │            ╭───────┴───────╮            │
           │            │               │            │
           ▼            ▼               ▼            ▼
    ╭──────────────╮  ╭──────────╮  ╭──────────╮  ╭──────────────╮
    │  ESTACIÓN 6  │  │INTEGRACIÓN│  │DESINTEG. │  │  ESTACIÓN 4  │
    │   Tipo 6     │  │    9     │  │    9     │  │   Tipo 4     │
    ╰──────┬───────╯  ╰──────────╯  ╰──────────╯  ╰──────┬───────╯
           │                                              │
           │            ╭───────┴───────╮            │
           │            │               │            │
           ▼            ▼               ▼            ▼
    ╭──────────────╮  ╭──────────╮  ╭──────────╮  ╭──────────────╮
    │  ESTACIÓN 5  │  │INTEGRACIÓN│  │DESINTEG. │  │   (etc...)   │
    │   Tipo 5     │  │    8     │  │    2     │  │              │
    ╰──────────────╯  ╰──────────╯  ╰──────────╯  ╰──────────────╯
```

---

## 📋 CONEXIONES ESPECÍFICAS POR ESTACIÓN

### 🎯 ESTACIÓN 1: EL RITMO JUSTO (Tipo 1)

**Alas**:
- **Ala 9 (izquierda)**: Se nutre de la paz y la aceptación
- **Ala 2 (derecha)**: Se aligera con el servicio consciente

**Flechas**:
- **Integración (7)**: La alegría libera la rigidez
- **Desintegración (4)**: La melancolía bloquea la acción

**Sección "Conecta Con" en la página**:
```
┌─────────────────────────────────────────────────────────────┐
│  🌟 EL RITMO JUSTO NO EXISTE EN AISLAMIENTO                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  🪽 ALAS - Los matices de tu justicia                       │
│                                                             │
│  [🟤 SABER CONSENTIDO] ← TÚ ESTÁS AQUÍ → [🟠 LAZOS]        │
│       (Tipo 9)              (Tipo 1)        (Tipo 2)        │
│       "La paz que           "La ética       "El amor       │
│        fundamenta"           en acción"      que suaviza"   │
│                                                             │
│  🔄 FLECHAS - Tus caminos de transformación                 │
│                                                             │
│  ⬆️ INTEGRACIÓN: CONCIENCIA ENERGÉTICA (7)                  │
│     "Cuando sueltas el control, encuentras la alegría"      │
│     → Explora cómo el entusiasmo libera tu perfección       │
│                                                             │
│  ⬇️ DESINTEGRACIÓN: DEVIDA ELECCIÓN (4)                     │
│     "Cuidado: la crítica excesiva te hunde en la envidia"   │
│     → Reconoce cuando la rigidez te aísla                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### 💝 ESTACIÓN 2: LAZOS DEL ALMA (Tipo 2)

**Alas**:
- **Ala 1 (izquierda)**: El servicio con límites éticos
- **Ala 3 (derecha)**: La ayuda que busca reconocimiento

**Flechas**:
- **Integración (4)**: La autenticidad sana el orgullo
- **Desintegración (8)**: El control disfrazado de amor

**Sección "Conecta Con"**:
```
┌─────────────────────────────────────────────────────────────┐
│  💝 LAZOS DEL ALMA EN EL SISTEMA                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  🪽 ALAS                                                    │
│  [🔵 RITMO JUSTO] ← TÚ ESTÁS AQUÍ → [🟢 ROLES]             │
│       (Tipo 1)              (Tipo 2)        (Tipo 3)        │
│       "El amor con           "El vínculo    "El éxito       │
│        principios"           consciente"     compartido"    │
│                                                             │
│  🔄 FLECHAS                                                 │
│  ⬆️ INTEGRACIÓN: DEVIDA ELECCIÓN (4)                        │
│     "Tu verdadera vocación: amar sin perderte"              │
│                                                             │
│  ⬇️ DESINTEGRACIÓN: EL HÁBITO (8)                           │
│     "Alerta: cuando el 'para ti' se vuelve control"         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### 🏆 ESTACIÓN 3: ROLES Y SINERGIA (Tipo 3)

**Alas**:
- **Ala 2 (izquierda)**: El éxito que conecta con otros
- **Ala 4 (derecha)**: La realización auténtica

**Flechas**:
- **Integración (6)**: La lealtad trasciende la imagen
- **Desintegración (9)**: La pereza de no ser

**Sección "Conecta Con"**:
```
┌─────────────────────────────────────────────────────────────┐
│  🏆 ROLES Y SINERGIA: MÁS ALLÁ DE LA IMAGEN                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  🪽 ALAS                                                    │
│  [🟠 LAZOS] ← TÚ ESTÁS AQUÍ → [🟣 DEVIDA]                  │
│       (Tipo 2)              (Tipo 3)        (Tipo 4)        │
│       "El éxito que         "El triunfo     "El logro       │
│        ayuda"                auténtico"      significativo" │
│                                                             │
│  🔄 FLECHAS                                                 │
│  ⬆️ INTEGRACIÓN: CENTRO DE MANDO (6)                        │
│     "La verdadera autoridad viene de la autenticidad"       │
│                                                             │
│  ⬇️ DESINTEGRACIÓN: SABER CONSENTIDO (9)                    │
│     "Cuidado: el olvido de ti mismo por el éxito"           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

### 🎨 ESTACIÓN 4: DEVIDA ELECCIÓN (Tipo 4)

**Alas**:
- **Ala 3 (izquierda)**: La unicidad que se realiza
- **Ala 5 (derecha)**: La profundidad que investiga

**Flechas**:
- **Integración (1)**: La acción ética da forma al arte
- **Desintegración (2)**: El orgullo de la especialidad

---

### 🔮 ESTACIÓN 5: PATRONES INVISIBLES (Tipo 5)

**Alas**:
- **Ala 4 (izquierda)**: El conocimiento con alma
- **Ala 6 (derecha)**: El análisis que decide

**Flechas**:
- **Integración (8)**: El poder del conocimiento aplicado
- **Desintegración (7)**: La dispersión del pensamiento

---

### ⚖️ ESTACIÓN 6: EL CENTRO DE MANDO (Tipo 6)

**Alas**:
- **Ala 5 (izquierda)**: La decisión informada
- **Ala 7 (derecha)**: La elección con entusiasmo

**Flechas**:
- **Integración (9)**: La paz más allá de la duda
- **Desintegración (3)**: La imagen que oculta el miedo

---

### ⚡ ESTACIÓN 7: CONCIENCIA ENERGÉTICA (Tipo 7)

**Alas**:
- **Ala 6 (izquierda)**: El entusiasmo que decide
- **Ala 8 (derecha)**: La energía que impacta

**Flechas**:
- **Integración (5)**: La profundidad en la experiencia
- **Desintegración (1)**: La rigidez del placer

---

### 👑 ESTACIÓN 8: EL HÁBITO DE LA PERSONALIDAD (Tipo 8)

**Alas**:
- **Ala 7 (izquierda)**: El poder con alegría
- **Ala 9 (derecha)**: La fuerza en paz

**Flechas**:
- **Integración (2)**: El poder que sirve
- **Desintegración (5)**: El aislamiento del control

---

### 🌟 ESTACIÓN 9: SABER CONSENTIDO (Matriz)

**Alas**:
- **Ala 8 (izquierda)**: La paz que se afirma
- **Ala 1 (derecha)**: La armonía ética

**Flechas**:
- **Integración (3)**: La acción consciente
- **Desintegración (6)**: La duda que paraliza

---

## 🧭 COMPONENTES DE NAVEGACIÓN

### 1. Menú Principal: La Rueda del Eneagrama

**Versión Desktop**:
```
                    [9]
                     │
            [8] ─────┼───── [1]
             │       │       │
             │       │       │
        [7] ─┼───────┼───────┼─ [2]
             │       │       │
             │       │       │
            [6] ─────┼───── [3]
                     │
                    [5]──[4]
```

- Hover sobre cada número: resalta y muestra nombre
- Click: navega a la estación
- Estación actual: indicador visual (brillo, borde, etc.)

**Versión Mobile**:
- Carrusel horizontal o lista vertical
- Indicador de tríada

### 2. Barra de Conexiones Contextuales

Aparece en cada página de especialización, mostrando:

```
┌────────────────────────────────────────────────────────────────┐
│  📍 Estás en: EL CENTRO DE MANDO (Tipo 6)                      │
├────────────────────────────────────────────────────────────────┤
│  🪽 Alas:  [Patrones Invisibles]  │  [Conciencia Energética]   │
│  🔄 Flechas:  [Saber Consentido ↑]  │  [Roles y Sinergia ↓]     │
└────────────────────────────────────────────────────────────────┘
```

### 3. Navegación por Tríadas

```
┌────────────────────────────────────────────────────────────────┐
│  EXPLORA POR TRÍADA                                            │
├────────────────────────────────────────────────────────────────┤
│  🧠 MENTAL (5-6-7)    ❤️ EMOCIONAL (2-3-4)    ⚡ INSTINTIVA    │
│                       (8-9-1)                                  │
│  Pensamiento          Sentimiento               Acción         │
│  Miedo → Confianza    Vergüenza → Amor        Ira → Paz        │
└────────────────────────────────────────────────────────────────┘
```

### 4. Breadcrumbs Sistémicos

```
Inicio > Tríada Mental > El Centro de Mando
         │
         └── [Ver todas las estaciones de esta tríada]
```

### 5. Footer: Mapa Completo

```
┌────────────────────────────────────────────────────────────────┐
│  MAPA DEL SISTEMA                                              │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│         🟤 SABER CONSENTIDO (9)                                │
│              │                                                 │
│    ⚫ HÁBITO ┼──── 🔵 RITMO JUSTO ──── 🟠 LAZOS               │
│       (8)    │       (1)              (2)                      │
│              │                                                 │
│    ⚡ CONCIENCIA ┼───────┼──── 🟢 ROLES                        │
│       (7)      │         │      (3)                           │
│                │         │                                    │
│    🔮 CENTRO ──┼─────────┼──── 🟣 DEVIDA                       │
│       (6)      │         │      (4)                           │
│                │         │                                    │
│    🌑 PATRONES ┴─────────┴──── [continúa...]                   │
│       (5)                                                      │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## 🎨 ESTADOS VISUALES DE NAVEGACIÓN

### Indicadores de Estado

| Estado | Visual | Descripción |
|--------|--------|-------------|
| **Normal** | Color sólido | Estado base |
| **Hover** | Brillo + escala | Interacción posible |
| **Activo** | Borde grueso + glow | Página actual |
| **Visitado** | Tono más suave | Ya explorado |
| **Relacionado** | Pulso sutil | Conexión con página actual |
| **Recomendado** | Animación | Sugerido por sistema |

### Transiciones entre Páginas

- **Misma tríada**: Transición suave, mismo tono cromático
- **Alas**: Transición con movimiento lateral
- **Flechas**: Transición con efecto de "ascenso" o "descenso"
- **Matriz**: Transición con zoom out/in

---

## 📱 PATRONES DE NAVEGACIÓN RESPONSIVE

### Desktop: Navegación Expandida
- Menú completo visible
- Sidebars con conexiones
- Hover effects elaborados
- Múltiples caminos visibles

### Tablet: Navegación Colapsada
- Menú en hamburguesa
- Conexiones en sección inferior
- Touch-friendly targets
- Swipe entre estaciones relacionadas

### Mobile: Navegación Prioritaria
- Menú simplificado
- "Siguiente estación sugerida" prominente
- Bottom navigation bar
- Gestos de swipe

---

## 🔍 BÚSQUEDA Y FILTRADO

### Motor de Búsqueda Avanzado

```
┌────────────────────────────────────────────────────────────────┐
│  🔍 Buscar en el ecosistema...                                 │
├────────────────────────────────────────────────────────────────┤
│  Filtrar por:                                                  │
│  [Todas las estaciones ▼] [Tipo de contenido ▼] [Nivel ▼]     │
│                                                                │
│  🏷️ Etiquetas populares:                                      │
│  #autoconocimiento #relaciones #trabajo #heridas #crecimiento │
│  #tipo1 #tipo4 #tríada-mental #integración                     │
└────────────────────────────────────────────────────────────────┘
```

### Resultados de Búsqueda

- Agrupados por estación
- Indicador visual de conexiones
- "También te puede interesar..."

---

## 🎯 EMBUDOS DE NAVEGACIÓN

### Embudo 1: Descubrimiento
```
Home → Test → Estación → Lead Magnet → Email → Nurturing → Compra
```

### Embudo 2: Exploración Profunda
```
Estación → Artículo → Estación relacionada → Curso → Compra
```

### Embudo 3: Comunidad
```
Cualquier página → Comunidad → Registro → Participación → Evento
```

---

*Documento creado como parte del sistema de entregables para Eneagramas: Saber Consentido*
